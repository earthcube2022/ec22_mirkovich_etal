#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import shutil,tempfile,datetime
from numpy import testing as nptest
import numpy as np
from AMGeO.observations.supermag import SuperMAG
from AMGeO.driver_default import _default_conductance_model,_default_supermag

def _date():
    return datetime.datetime(2015,3,16)

def _time_range():
    startdt=_date()+datetime.timedelta(hours=3,minutes=0)
    enddt=_date()+datetime.timedelta(hours=3,minutes=5)
    return startdt,enddt

def _sm_instance():
    asim_date = _date()
    return _default_supermag(asim_date)

@pytest.fixture(scope='module')
def sm_instance(request):
    return _sm_instance()

def test_north_supermag_declination_is_nonzero(sm_instance):
    """10-2-2019, I found that all SuperMAG declinations
    on their website were zero if you viewed the data
    in the tables. I'm putting in a test to make sure
    that's not happening with our data. Also this
    is a basic 'does it run' test."""
    startdt,enddt = _time_range()
    data_window_args = (startdt,enddt,'N','all')
    datadict,metadata = sm_instance.get_data_window(*data_window_args)
    assert np.any(datadict['decl']!=0.)

def test_south_has_only_negative_latitudes(sm_instance):
    startdt,enddt = _time_range()
    data_window_args = (startdt,enddt,'S','all')
    datadict,metadata = sm_instance.get_data_window(*data_window_args)
    assert np.all(datadict['lats']<0.)

