import numpy as np
import traceback
from geospacepy import special_datetime
try:
    from apexpython.apex_converter import apex_converter
except ImportError:
    print(traceback.format_exc())
    from apexpy.apex_converter import apex_converter

class ObservationApexLocations(object):
    """
    A class representing a set of locations of observations

    Attributes
    ----------
    alts : np.ndarray
        Observation altitudes
    apexconv : apexpy.apex_converter
        Converter instance used for coordinate conversions
    dts : list
        Timestamps for observations
    glats : np.ndarray
        Geographic latitudes
    glons : np.ndarray
        Geographic longitudes
    hr : float
        Apex reference altitude (110 km by default)
    lons : np.ndarray
        Apex longitudes if mlon_is_mlt_in_degrees is false
        otherwise 'longitudes' (MLT in degrees)
    tile_locs_to_dts : bool
        Switch for apex-ing SuperMAG data, if this is True
        apex locations for all passed
        glats and glons will be calculated
        for each datetime in dts. If False, an error will
        be raised if glats/glons and dts and not the same shape
    mlon_is_mlt_in_degrees : bool
        Switch to tell whether we use magnetic longitude or
        AMGeO magnetic 'longitude' (MLT in degrees)
    mlts : np.ndarray
        Magnetic local times
    Re : float
        Earth radius in km (6371.2)
    sinIm : np.ndarray
        sine of apex 'magnetic pseudo-inclination' (coordinate system
        geometric factor needed by derivatives, etc.)
    """
    def __init__(self,dts,glats,glons,alts,igrf_epoch,hr=110.,
                    tile_locs_to_dts=False,mlon_is_mlt_in_degrees=True,
                    altmin=200.,altmax=900.):
        self.apexconv = apex_converter(epoch=igrf_epoch,
                                        altmin=altmin,
                                        altmax=altmax)
        self.mlon_is_mlt_in_degrees = mlon_is_mlt_in_degrees
        self.tile_locs_to_dts = tile_locs_to_dts
        self.hr = hr # Apex reference height (110 km by default)
        self.Re = 6371.2 #Earth radius (mean)
        self.dts = dts
        self.glats = glats
        self.glons = glons
        self.alts = alts
        self.compute_apex()

    def compute_apex(self):
        """
        Convert the observation locations in geocentric to apex
        """
        lats,lons,qdlats = self.apexconv.geo2apex(self.glats,
                                                    self.glons,
                                                    self.alts,
                                                    hr=self.hr)


        years = np.array([dt.year for dt in self.dts])
        doys,uts = special_datetime.datetimearr2doy(self.dts),special_datetime.datetimearr2sod(self.dts)

        if not self.tile_locs_to_dts:

            self.lats = lats
            self.lons = lons

        else:

            self.lats = np.tile(lats.reshape(1,-1),(len(self.dts),1))
            self.lons = np.tile(lons.reshape(1,-1),(len(self.dts),1))

            years = np.tile(years.reshape(-1,1),(1,len(lats)))
            doys = np.tile(doys.reshape(-1,1),(1,len(lats)))
            uts = np.tile(uts.reshape(-1,1),(1,len(lats)))

        self.mlts = self.apexconv.alon2mlt(self.lons.flatten(),
                                            years.flatten(),
                                            doys.flatten(),
                                            uts.flatten())

        self.mlts = self.mlts.reshape(self.lats.shape)


        #I think AMGeO basis functions are specified in terms of 'longitude' being
        #MLT in degrees and not actually apex longitude
        if self.mlon_is_mlt_in_degrees:
            self.lons = self.mlts/12*180.

        #Copy apex basis vectors and pseudo-inclination to class
        self.d1,self.d2,self.d3 = self.apexconv.lastrun['d1'],self.apexconv.lastrun['d2'],self.apexconv.lastrun['d3']
        self.e1,self.e2,self.e3 = self.apexconv.lastrun['e1'],self.apexconv.lastrun['e2'],self.apexconv.lastrun['e3']
        self.f1,self.f2 = self.apexconv.lastrun['f1'],self.apexconv.lastrun['f2']
        self.sinIm = self.apexconv.lastrun['sim']
