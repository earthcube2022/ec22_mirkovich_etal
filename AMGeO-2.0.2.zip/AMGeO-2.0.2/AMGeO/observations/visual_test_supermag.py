#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import shutil,tempfile,datetime,os
import numpy as np
import matplotlib.pyplot as plt
from AMGeO.observations.test_supermag import _time_range,_sm_instance
from geospacepy import satplottools

def _figure_axes():
    f = plt.figure(figsize=(10,10))
    axNs = [f.add_subplot(2,2,i) for i in [1,2]]
    axSs = [f.add_subplot(2,2,i) for i in [3,4]]
    for axN,axS in zip(axNs,axSs):
        satplottools.draw_dialplot(axN)
        satplottools.draw_dialplot(axS)

    return f,axNs,axSs

if __name__ == '__main__':

    sm = _sm_instance()

    f,axNs,axSs = _figure_axes()
    for axs,hemisphere in zip([axNs,axSs],['N','S']):
        ax_vec,ax_scat = axs

        startdt,enddt = _time_range()
        allowed_observers = 'all'
        obs_args = (startdt,enddt,hemisphere,allowed_observers)

        sm.plot_vectors(ax_vec,*obs_args)

        datadict,metadata = sm.get_data_window(*obs_args)
        X,Y = satplottools.latlt2cart(datadict['lats'],
                                        datadict['lons']/180*12,
                                        hemisphere)

        Bz = datadict['data_fieldaligned']
        mappable = ax_scat.scatter(X,Y,5,Bz,edgecolor='none',
                                    vmin=-1*metadata['typicalvalue']/10.,
                                    vmax=metadata['typicalvalue']/10.,
                                    cmap='bwr')

        f.colorbar(mappable,ax=ax_scat)

    plt.tight_layout()

    dtfmt = lambda dt: dt.strftime('%H:%M:%S')
    f.suptitle(str(sm)+'\n{}-{}'.format(dtfmt(startdt),dtfmt(enddt)))

    f.savefig(os.path.expanduser('~/visual_test_supermag.png'))
