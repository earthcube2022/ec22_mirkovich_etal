#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import json, os
from collections import OrderedDict
from AMGeO.files.directories import data_dir, default_output_dir

def input23(prompt):
	try:
		return raw_input(prompt)
	except NameError:
		#Python 3
		return input(prompt)

config_file = os.path.join(data_dir,'amgeo_user.json')

def create_config():
	config = {}
	config['amgeo']={}
	print('Please register with AMGeO here: https://amgeo.colorado.edu/register\n\n' +
		'Once registered, go to your account and get your API key here: https://amgeo.colorado.edu/protected/account')
	print()
	config['amgeo']['api_key']=input23("Enter your AMGeO API key: ")
	print()

	config['supermag']={}
	print('Please register with SuperMAG here: https://supermag.jhuapl.edu/\n\nWhen registered, please enter your SuperMAG username')
	print()
	config['supermag']['username']=input23("Enter your SuperMAG username: ")
	print()

	config['ampere']={}
	print('Please register with AMPERE here: https://ampere.jhuapl.edu/\n\nWhen registered, please enter your AMPERE username')
	print()
	config['ampere']['username']=input23("Enter your Ampere username: ")

	# config['superdarn']={}
	# config['superdarn']['username']=input23("Enter your SuperDARN username: ")
	# config['superdarn']['password']=input23("Enter your SuperDARN password: ")

	#Currently, there is no need to authenticate with the superdarn
	#data service
	config['superdarn']={}
	config['superdarn']['username']='amgeouser'
	config['superdarn']['password']='none'
	
	return config

def load_config():
	load_kwargs = {'object_pairs_hook':OrderedDict} #Preserve order from file
	if os.path.exists(config_file):
		with open(config_file,'r') as f:
			config = json.load(f,**load_kwargs)
	else:
		config = create_config()
		save_config(config)
	return config

def save_config(config):
	dump_kwargs = {'indent':2} #Keep the file readable after modifying
	with open(config_file,'w') as f:
		json.dump(config,f,**dump_kwargs)

class Config:

	def __init__(self, name, directory=data_dir):
		# if exists, load
		self.config_file = data_dir + '/' + name + '_amgeo_config.json'
		#print(self.config_file)
		if (os.path.isfile(self.config_file)):
			# read file data from json
			with open(self.config_file,'r') as f:
				self.data = json.load(f)
		else:
			self.data = {
				'output_dir': default_output_dir
			}
		pass

	def set_output_dir(self, output_dir):
		self.data['output_dir'] = output_dir

	def get_output_dir(self):
		return self.data['output_dir']

	def save(self):
		with open(self.config_file,'w') as f:
			json.dump(self.data, f)