from AMGeO.controllers.default_controller import DefaultController
from AMGeO.files.config import Config, create_config, save_config
from os.path import abspath

class AMGeOApi:

    def __init__(self, config_name='default'):
        """Creates an AMGeOApi instance, which can be used to set
        your AMGeO environment as well as create AMGeO Controllers
        for easy Assimilative map generation/loading 

        Parameters
        ----------
            config_name : str
                The name of the AMGeO configuration you would like to load.
                By default, will load the configuration with name 'default'
        """
        self.config_name = config_name
        self.config = Config(self.config_name)
        self.config.save() # need to save everytime something is changed

    def __repr__(self) -> str:
        return 'AMGeO API instance\ncurrent configuration: %s\ncurrent output directory: %s\n' % (self.config_name, self.get_output_dir())

    def set_output_dir(self, output_dir):
        """Sets the output directory for AMGeO Assimilative maps

        Parameters
        ----------
            output_dir : str
                The output directory that you would like to set. 
                
                Can be a relative path, such as './cwdir', 
                or an absolute path, such as '/home/my/output/dir'

        """
        output_dir = abspath(output_dir)
        self.config.set_output_dir(output_dir)
        self.config.save()

    def get_output_dir(self) -> str:
        """Returns the current output directory for AMGeO Assimilative maps
        """
        return self.config.get_output_dir()

    def get_controller(self, kind=None):
        """Creates and returns a controller class for generating/loading AMGeO maps

        Parameters
        ----------
            kind : 'default'
                The controller type you would like to use. By default, will return 
                a 'DefaultController'

                NOTE: currently, the only controller supported by AMGeO is a 'DefaultController'
        """
        if (kind):
            if (kind == 'default'):
                return DefaultController(self)
            else:
                raise Exception("kind='%s' is not supported")
        else:
            return DefaultController(self)

    # TODO: decide on possible better name, maybe set_credentials?
    def set_configuration(self):
        """Sets configuration for AMGeO, which includes your:
            - AMGeO API key
            - SuperMAG username
            - AMPERE username
        """
        config = create_config()
        save_config(config)