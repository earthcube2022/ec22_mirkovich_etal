#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import functools
import numpy as np
from AMGeO.basis.functions import basis_functions_set as basisset
from AMGeO.datamodel.record import RecordMetadata
from AMGeO.caching import CachedArrayInputFunction
from AMGeO.basis.apex import module_Apex
from AMGeO.basis.apex import (update_apex_epoch,apex_reference_height)
from geospacepy.special_datetime import (doyarr2datetime,
                                        datetimearr2jd,
                                        datetime2jd,
                                        datetime2doy)

R_EARTH = 6.3712e6 #m
R_IONOSPHERE = R_EARTH+110000. #m
MU_0 = 4*np.pi*1e-7 #Permeability of free space [T*m/A]=[kg*m/(s^2*A^2)]

#Convention of what component of vector corresponds to what
#index into the 3rd dimension of 3 dimensional arrays
_2D_components = ['eastward','equatorward']
_3D_components = _2D_components+['fieldaligned']
_component_indices = {'eastward':0,'equatorward':1,'fieldaligned':2}
_component_shortnames = {'eastward':'ph','equatorward':'th','fieldaligned':'B'}

def _component_metadata_from_vector_metadata(vector_metadata,component_name):
    component_metadata = vector_metadata.copy()
    component_metadata['shortname']+='_'+_component_shortnames[component_name]
    component_metadata['longname']+=' ({})'.format(component_name)
    return component_metadata

def _component_array_from_3D_array(H,component_name):
    return H[:,:,_component_indices[component_name]]

def returns_scalar(basis_physics_function):
    @functools.wraps(basis_physics_function)
    def returns_scalar_wrapper(*args,**kwargs):
        return basis_physics_function(*args,**kwargs)
    returns_scalar_wrapper._components = None
    return returns_scalar_wrapper

def returns_2D_vector(basis_physics_function):
    @functools.wraps(basis_physics_function)
    def returns_2D_vector_wrapper(*args,**kwargs):
        return basis_physics_function(*args,**kwargs)
    returns_2D_vector_wrapper._components = _2D_components
    return returns_2D_vector_wrapper

def returns_3D_vector(basis_physics_function):
    @functools.wraps(basis_physics_function)
    def returns_3D_vector_wrapper(*args,**kwargs):
        return basis_physics_function(*args,**kwargs)
    returns_3D_vector_wrapper._components = _3D_components
    return returns_3D_vector_wrapper

@returns_scalar
def get_electric_potential(lats,lons):
    """Get the basis functions values at locations lats,lons which
    are used to represent the electric potential.

    Electric potential is one of the fundamental physical paramemters
    used in AMGeO (it is the state variable for one of the solvers),
    so it is represented by just the basis functions values themselves,
    not the deriviatives, and no scaling factors are needed

    Inputs:
        lats - np.ndarray, nloc
            Array of Apex latitudes
        lons - np.ndarray, nloc
            Array of Magnetic Local Times in degrees

    Returns
        epot - np.ndarray, nloc
    """
    metadata = RecordMetadata('epot','Electric Potential','V')
    return basisset.basis_functions(lats,lons),metadata

@returns_scalar
def get_magnetic_potential(lats,lons):
    """Get the basis functions values at locations lats,lons which
    are used to represent the magnetic potential.

    Magnetic potential is one of the fundamental physical paramemters
    used in AMGeO (it is the state variable for one of the solvers),
    so it is represented by just the basis functions values themselves,
    not the deriviatives, and no scaling factors are needed

    Inputs:
        lats - np.ndarray, nloc
            Array of Apex latitudes
        lons - np.ndarray, nloc
            Array of Magnetic Local Times in degrees

    Returns
        mpot - np.ndarray, nloc
    """
    metadata = RecordMetadata('mpot','Magnetic Potential','cT/m')
    return basisset.basis_functions(lats,lons),metadata

@returns_scalar
def get_field_aligned_current(lats,lons):
    """Get the basis functions appropriate for field aligned currents
    at the locations lats,lons
    
    Field aligned current is defined as the horizontal laplacian of the 
    toroidal potential, muliplied by one over the permeability of free space
    (mu_0)

    Inputs:
        lats - np.ndarray, nloc
            Array of Apex latitudes
        lons - np.ndarray, nloc
            Array of Magnetic Local Times in degrees

    Returns
        jfac - np.ndarray, nloc
    """
    metadata = RecordMetadata('jfac','Field Aligned Current','uA/m^2')
    laplacian = basisset.nnp1
    mpot,mpotmeta = get_magnetic_potential(lats,lons)
    mpot/=1.0e2 # cT->T
    jfac = np.full_like(mpot,np.nan)
    for iloc in range(len(lats)):
        jfac[iloc,:]=(1/MU_0)*(-1/R_IONOSPHERE**2)*laplacian*mpot[iloc,:]
    jfac*=1.0e6 # A/m^2 -> uA/m^2
    return jfac,metadata

@returns_2D_vector
def get_electric_field(lats,lons):
    """
    Get the amgeo basis function values at locations lats,lons for
    the electric field

    Inputs:
        lats - np.ndarray, nloc
            Array of Apex latitudes
        lons - np.ndarray, nloc
            Array of Magnetic Local Times in degrees

    Returns
        efield_th - np.ndarray, nloc
            electric field in d2 direction
        efield_ph - np.ndarray, nloc
            electric field in d1 direction
    """
    metadata = RecordMetadata('E','Electric Field','V/m')

    th = np.radians(90.-lats) # colatitude
    pot,dpotdph,dpotdth = basisset.basis_functions(lats,lons,derivatives=True)
    efield_ph, efield_th = np.zeros_like(dpotdph),np.zeros_like(dpotdth)
    for i_basis in range(dpotdph.shape[1]):
        efield_ph[:,i_basis] = dpotdph[:,i_basis]/np.sin(th)/R_IONOSPHERE
        efield_th[:,i_basis] = dpotdth[:,i_basis]/R_IONOSPHERE
    #Ellen takes the negative for some reason
    return np.dstack([-1.*efield_ph,-1.*efield_th]),metadata

@returns_2D_vector
def get_ion_velocity(lats,lons,radEarth=6371.,alt=110.):
    """
    Inputs:
        lats - np.ndarray, nloc
            Array of Apex latitudes
        lons - np.ndarray, nloc
            Array of Magnetic Local Times in degrees

    Returns
        v_th - np.ndarray, nloc
            ion velocity in d2 (equatorward) direction
        v_ph - np.ndarray, nloc
            ion velocity in d1 (eastward) direction

    """
    metadata = RecordMetadata('v','Ion Drift Velocity','m/s')

    E,Emeta = get_electric_field(lats,lons)

    efield_ph = _component_array_from_3D_array(E,'eastward')
    efield_th = _component_array_from_3D_array(E,'equatorward')

    nbasis = efield_th.shape[1]

    theta = np.radians(90.-abs(lats))
    bFldPolar = 0.62e-4
    bvals = bFldPolar*(1. - 3.*alt/radEarth)*np.sqrt(3.*np.square(np.cos(theta)) + 1.)/2
    bvals = np.tile(bvals,(nbasis,1)).T

    v_th = -1.*efield_ph/bvals
    v_ph = efield_th/bvals
    return np.dstack([v_ph,v_th]),metadata

# def get_igrf_B(lats,lons,dt,approx_alt=110.):
#   """
#   Compute the vertical component of the IGRF field
#   at locations given by magnetic latitudes lats and longitudes lons

#   Inputs:
#       lats - np.ndarray, nloc
#           Array of Apex latitudes
#       lons - np.ndarray, nloc
#           Array of Apex longitude

#   Returns:
#       Be - np.ndarray, nloc
#           Array of IGRF eastward main field components
#       Bn - np.ndarray, nloc
#           Array of IGRF northward main field components
#       Bu - np.ndarray, nloc
#           Array of IGRF upward main field components

#   """
#   mlon = amgeo_core.mlt2mlon(lons/180.*12.) #Because if we're doing AMGeO grids then mlon is MLT in degrees
#   gdlat,gdlon = amgeo_core.core_apex_converter.apex2geo(lats,mlon,approx_alt)
#   Be,Bn,Bu = igrfpy.getmainfield(dt,gdlat,gdlon,np.ones_like(gdlat)*approx_alt,geocentric=False,silent=True)
#   Be = np.array(Be)*1.0e-9 # It returns lists, convert to array, and then from nT to T
#   Bn = np.array(Bn)*1.0e-9 # It returns lists, convert to array, and then from nT to T
#   Bu = np.array(Bu)*1.0e-9 # It returns lists, convert to array, and then from nT to T
#   return Be,Bn,Bu

@returns_2D_vector
def get_magnetic_perturbations(lats,lons,dt,hemisphere):
    """
    Compute the basis functions at locations given by the magnetitude latitudes lats and longitudes lons

    Inputs:
        lats - np.ndarray, nloc
            Array of Apex latitudes
        lons - np.ndarray, nloc
            Array of Magnetic Local Times in degrees

    Returns
        dBd1 - np.ndarray, nloc
            magnetic flux density in d1 direction (nT)
        dBd2 - np.ndarray, nloc
            magnetic flux density in d2 direction (nT)
    """
    metadata = RecordMetadata('sdB','Spacecraft-Observed Magnetic Perturbations','nT')
    # import pdb
    # pdb.set_trace()
    update_apex_epoch(dt)

    if hemisphere == 'N':
        hemisign=1.
    elif hemisphere == 'S':
        hemisign=-1.
    else:
        raise ValueError('Invalid hemisphere {} (not N or S)'.format(hemisphere))

    #AMGeO latitudes are absolute apex latitudes
    alats = hemisign*lats

    #AMGeO longitudes are magnetic local time in degrees,
    #so we must convert to get actual apex longitudes
    alons = np.full_like(lons,np.nan)
    mlts = lons/180.*12.
    for i in range(np.size(mlts)):
        alons[i] = module_Apex.mlt2mlon(mlts[i],dt)

    #Apex to Quasi-dipole calculation needs an altitude in kilometers
    #TBD is it really correct to do this transformation at the
    #apex reference height?
    heights_km = apex_reference_height/1000. #m -> km
    qdlats,qdlons = module_Apex.apex2qd(alats,alons,heights_km)

    #
    gdlats,glons,alt = module_Apex.apex2geo(alats,alons,heights_km)
    
    #returns f1,f2,f3,g1,g2,g3,d1,d2,d3,e1,e2,e3
    basisvecouts = module_Apex.basevectors_apex(gdlats,glons,heights_km)
    f1,f2,f3 = basisvecouts[0],basisvecouts[1],basisvecouts[2]
    e1,e2,e3 = basisvecouts[-3],basisvecouts[-2],basisvecouts[-1]
    
    #Geometric/coordinate factors
    sinqdlat = np.sin(np.radians(qdlats))
    cosqdlat = np.cos(np.radians(qdlats))

    ref_height_ratio = apex_reference_height/R_EARTH

    aqfac = np.abs(sinqdlat)/np.sqrt(sinqdlat*sinqdlat + ref_height_ratio)

    #Check these are in the right order
    term_d1_ph = (e1[0,:]*f2[0,:]+e1[1,:]*f2[1,:])/cosqdlat  # fac_dlon_e1f2
    term_d1_th = hemisign*(e1[0,:]*f1[0,:]+e1[1,:]*f1[1,:])*aqfac     # fac_dlat_e1f1
    term_d2_ph = (e2[0,:]*f2[0,:]+e2[1,:]*f2[1,:])/cosqdlat  # fac_dlon_e2f2
    term_d2_th = hemisign*(e2[0,:]*f1[0,:]+e2[1,:]*f1[1,:])*aqfac     # fac_dlat_e2f1    

    pot,dpotdph,dpotdth = basisset.basis_functions(np.abs(lats.flatten()),
                                                    lons.flatten(),
                                                    derivatives=True)

    dBd1,dBd2 = np.zeros_like(pot),np.zeros_like(pot)
    dBd1.fill(np.nan)
    dBd2.fill(np.nan)
    for i_basisfcn in range(dpotdph.shape[1]):
        dBd1[:,i_basisfcn] = term_d1_ph*dpotdph[:,i_basisfcn]/R_IONOSPHERE + \
                                term_d1_th*dpotdth[:,i_basisfcn]/R_IONOSPHERE
        dBd2[:,i_basisfcn] = term_d2_ph*dpotdph[:,i_basisfcn]/R_IONOSPHERE + \
                                term_d2_th*dpotdth[:,i_basisfcn]/R_IONOSPHERE

    #To nT
    dBd1,dBd2 = dBd1*1.0e7,dBd2*1.0e7

    return np.dstack([dBd1,dBd2]),metadata


@CachedArrayInputFunction
def calc_potcoeff_to_groundmagcoeff(cond_ped,cond_hall,nlons=36,fma_dtype=np.float):
    """
    Compute the n_basis x n_basis matrices (one for vertical (Z), one for
    horizontal (D,H) components) which map AMGeO basis function coefficents
    which can represent the electric potential (at Apex reference height)
    to those which can be used to represent ground magnetic perturbations

    cond_hall, np.ndarray shape = (basisset.qmeta['ithmx'],nlons), optional
        Hall conductance for latitudes of the AMGeO grid, with a variable number of equally spaced longitudes

    cond_ped, np.ndarray shape = (basisset.qmeta['ithmx'],nlons), optional
        Hall conductance for latitudes of the AMGeO grid, with a variable number of equally spaced longitudes

    nlons, int,optional
        number of longitudes to compute for the grid over which
        numerical integrations will be performed. By default (if it stays as None)
        it is set to 36 or the maximum azimuthal wavenumber of any of the basis functions
    """

    mmx = basisset.qmeta['mmx']
    nbasis = basisset.iem[2*mmx]+1

    #Colatitudes in radians of qset lat grid
    thetas,lats = basisset.theta,basisset.abslats
    #Difference between adjacent thetas in original grid
    dth = basisset.qmeta['dth']
    #Longitudes (used for numerical 'integration')
    dlon = 360./nlons
    lons = np.linspace(dlon,360.,nlons) # This will produce identical output at every step to Fortran code
    #lons = np.linspace(0.,360.,nlons+1)

    # if basisset.cached_cond_ped is not None and basisset.cached_cond_hall is not None:
    #     if basisset.cached_cond_hall.shape == cond_hall.shape:
    #         if np.isclose(cond_ped,basisset.cached_cond_ped).all() and np.isclose(cond_hall,basisset.cached_cond_hall).all():
    #             print "Conductance arrays not changed using cached pot->groundmag (ZFMA,VFMA) mapping values"
    #             return basisset.cached_ZFMA,basisset.cached_VFMA,basisset.cached_TFMA,basisset.cached_PSFMA

    n_amgeo_lats = len(basisset.q[0,:]) #Should also equal basisset.qmeta['ithmx']

    q_sym = np.zeros((nbasis,n_amgeo_lats),dtype=fma_dtype)
    dq_sym = np.zeros((nbasis,n_amgeo_lats),dtype=fma_dtype)
    q_asym = np.zeros((nbasis,n_amgeo_lats),dtype=fma_dtype)
    dq_asym = np.zeros((nbasis,n_amgeo_lats),dtype=fma_dtype)
    intCur_th = np.zeros((nbasis,2*mmx+1,n_amgeo_lats),dtype=fma_dtype)
    intCur_ph = np.zeros((nbasis,2*mmx+1,n_amgeo_lats),dtype=fma_dtype)

    #Get azimuthal part of basis functions and their derivitives wrt longitude/phi
    #evaluated at longitudes lons
    f_m,df_m = basisset.compute_f(lons,derivative=True)

    all_m = range(-mmx,mmx+1)
    for i_m,m in enumerate(all_m):

        # f_m for all longitudes for this m
        this_f_m = f_m[i_m,:]
        # derivative of f_m wrt longitude for this m
        this_df_m = df_m[i_m,:]

        #Find the basis function numbers which correspond to all basis functions
        #for this value of m
        i_basisfcn_m = range(basisset.ibm[i_m],basisset.iem[i_m]+1)

        for i_n,i_basisfcn in enumerate(i_basisfcn_m):

            row_n_start = basisset.ns[abs(m)] # Row at which the n values start for this m

            this_n_row_sym = row_n_start+2*i_n # This would be symmetric, i.e. m < 0, so f_m~cos(m*phi)
            this_n_row_asym = row_n_start+2*i_n+1 # This would be antisymmetric, i.e. m > 0, so f_m~sin(m*phi)

            # nmx(m) = mxnmx-|m|
            q_sym[i_basisfcn,:],dq_sym[i_basisfcn,:] = basisset.q[this_n_row_sym,:],basisset.dq[this_n_row_sym,:]
            q_asym[i_basisfcn,:],dq_asym[i_basisfcn,:] = basisset.q[this_n_row_asym,:],basisset.dq[this_n_row_asym,:]

            for ith,theta in enumerate(thetas):
                for ilon,lon in enumerate(lons):
                    #The +1 is due to a off-by-one in the Fortran where the first row and column of the
                    #conductance is ignored
                    SigP,SigH = cond_ped[ith,ilon],cond_hall[ith,ilon]
                    E_th = -1.*dq_sym[i_basisfcn,ith]*this_f_m[ilon]/R_IONOSPHERE
                    E_ph = -1.*q_sym[i_basisfcn,ith]*this_df_m[ilon]/(R_IONOSPHERE*np.sin(theta))
                    Cur_th = SigP*E_th + SigH*E_ph
                    Cur_ph = SigP*E_ph - SigH*E_th
                    #if debug:
                    #   if ith <= 4 and ilon == nlons-1 and m==12 and i_n==0:
                    #       print "--------------------"
                    #       print "i_basisfcn= %d, m = %d, i_n = %d" % (i_basisfcn,m,i_n)
                    #       print "f_m: %e, df_m: %e" % (this_f_m[ilon],this_df_m[ilon])
                    #       print "Qsym: %e, dQsym: %e" % (q_sym[i_basisfcn,ith],dq_sym[i_basisfcn,ith])
                    #       print "Lat:%f,Lon:%f" % (90.-np.degrees(theta),lon)
                    #       print "E Efield: %e, N Efield %e" % (E_ph,E_th)
                    #       print "E Current: %e, N Current %e" % (Cur_ph,Cur_th)
                    #       print "SigP:%f, SigH:%f" % (SigP,SigH)
                    #       print "Re*sin(theta)= %f" % (basisset.R_IONOSPHERE*np.sin(theta))
                    #Don't know what this is doing still, just copied over from FTran
                    intCur_th[i_basisfcn,:,ith] = intCur_th[i_basisfcn,:,ith] + Cur_th*f_m[:,ilon]/nlons
                    intCur_ph[i_basisfcn,:,ith] = intCur_ph[i_basisfcn,:,ith] + Cur_ph*f_m[:,ilon]/nlons

    #test_i_basisfcn = 8
    #test_ith = 8
    #for i_m,m in enumerate(all_m):
    #   print "I=%d, lat=%.2f, M=%d, Longitude Integrated Current: E: %e N: %e" % (test_i_basisfcn,
    #       lats[test_ith],m,
    #       intCur_ph[test_i_basisfcn,i_m,test_ith],intCur_th[test_i_basisfcn,i_m,test_ith])

    #I haven't yet found exactly what these are
    #they are related to the equivalent current functions
    TFMA = np.zeros((nbasis,nbasis),dtype=fma_dtype)
    PSFMA = np.zeros((nbasis,nbasis),dtype=fma_dtype)
    ZFMA = np.zeros((nbasis,nbasis),dtype=fma_dtype)
    VFMA = np.zeros((nbasis,nbasis),dtype=fma_dtype)

    for ith,theta in enumerate(thetas):

        #Sum over m,n
        for i_m,m in enumerate(all_m):
            i_neg_m = len(all_m)-i_m-1 # index of -m
            i_basisfcn_m = range(basisset.ibm[i_m],basisset.iem[i_m]+1)
            for i_n,i_basisfcn in enumerate(i_basisfcn_m):
                #Integrate over theta
                #TFMA - transformation matrix taking coefficeints for electric potential?
                #to coefficients for Tau, the 'current potential'
                #I_p = -grad(tau) where I_p is the 'potential current', AKA current which closes FACs
                TFMA[i_basisfcn,:] = TFMA[i_basisfcn,:] - dq_sym[i_basisfcn,ith]*intCur_th[:,i_m,ith]*R_IONOSPHERE*dth*np.sin(theta)
                TFMA[i_basisfcn,:] = TFMA[i_basisfcn,:] - q_sym[i_basisfcn,ith]*intCur_ph[:,i_neg_m,ith]*m*R_IONOSPHERE*dth
                #PSFMA - coefficient transformations for electric potential? to coefficents for
                #Psi, the equivalent current function
                #I_t = r_hat x grad(psi) where I_t = toroidal current, r_hat is paralell to field lines
                PSFMA[i_basisfcn,:] = PSFMA[i_basisfcn,:] + dq_asym[i_basisfcn,ith]*intCur_ph[:,i_m,ith]*R_IONOSPHERE*dth*np.sin(theta)
                PSFMA[i_basisfcn,:] = PSFMA[i_basisfcn,:] - q_asym[i_basisfcn,ith]*intCur_th[:,i_neg_m,ith]*R_IONOSPHERE*m*dth

    #We need values (of PSFMA) for all n for this m
    #to compute
    #ZFMA and VFMA so we
    #must do this loop again
    for i_m,m in enumerate(all_m):
        i_neg_m = len(all_m)-i_m-1 # index of -m
        i_basisfcn_m = range(basisset.ibm[i_m],basisset.iem[i_m]+1)
        for i_n_out,i_basisfcn_out in enumerate(i_basisfcn_m):
            # i_p is row of vfmps/zfmps tables
            # nss[i_m] gives row of first n for this m into vfmps/zfmps
            i_p = i_n_out + basisset.nss[np.abs(m)]
            #Summation over all n for this m
            #print "M=%d,I_N=%d,I_P=%d,ZFMPS=%e" % (m,i_n_out,i_p,basisset.zfmps[i_p,0])
            for i_n_in,i_basisfcn_in in enumerate(i_basisfcn_m):
                #There's an implicit assumption here: that FAC don't contribute to ground mag perturbations
                #because JFAC = div(Ip) = div(-grad(tau)) and TFMA does not factor in the computation
                #of ZFMA and VFMA
                ZFMA[i_basisfcn_out,:] = ZFMA[i_basisfcn_out,:] + basisset.zfmps[i_p,i_n_in]*PSFMA[i_basisfcn_in,:]
                VFMA[i_basisfcn_out,:] = VFMA[i_basisfcn_out,:] + basisset.vfmps[i_p,i_n_in]*PSFMA[i_basisfcn_in,:]
                #if i_basisfcn_out == 2:
                #    print "i=%d,M=%d,i_n=%d,VFMA[i,21]=%e,PSFMA[1,21],vfmps=%e,psfma=%e" % (i_basisfcn_in,m,i_n_in,
                #       VFMA[i_basisfcn_out,21],basisset.vfmps[i_p,i_n_in],PSFMA[i_basisfcn_in,21])

    # self.cached_ZFMA,self.cached_VFMA,self.cached_PSFMA,self.cached_TFMA = ZFMA,VFMA,PSFMA,TFMA
    # self.cached_cond_hall = cond_hall
    # self.cached_cond_ped = cond_ped

    return ZFMA,VFMA,TFMA,PSFMA

@returns_3D_vector
def get_ground_magnetic_perturbations(lats,lons,cond_ped,cond_hall):
    """

    Get the coefficient for the AMGeO basis function
    set which describe expansions of each of the three components

        H - ? North
        D - ? East
        Z - ? Down

    of magnetic perturbations at the ground as observed by
    ground magnetometers (e.g. SuperMAG)

    """
    metadata = RecordMetadata('gdB','Ground-based Magnetic Perturbations','nT')

    #Get coefficient sets for potential and it's derivatives
    pots,dpotsdph,dpotsdth = basisset.basis_functions(lats,lons,derivatives=True)

    #Get sine of colats and earth radius (constants that appear in the coefficient formulae)
    sin_theta = np.sin(np.radians(90.-lats))
    Ri = R_IONOSPHERE

    #Get electric to ground magnetic pertubation AMGeO basis function
    #coefficient transformation matrices
    zfma,vfma,tfma,psfma = calc_potcoeff_to_groundmagcoeff(cond_ped,cond_hall)

    #Components of the ground magnetic pertrubations
    ZMG = pots

    HMG = dpotsdth/Ri*1.0e9
    #Divide through by sine of colatitude
    for col in range(HMG.shape[1]):
        HMG[:,col]/sin_theta

    DMG = -1.*dpotsdph/Ri*1.0e9
    #DMG = dpotsdph/Ri*1.0e9

    #Formulae from matlab setbase_gmagobs.m,
    HMG = np.dot(HMG,vfma)
    DMG = np.dot(DMG,vfma)
    ZMG = np.dot(ZMG,zfma)

    #To nT
    #HMG,DMG,ZMG = HMG,DMG,ZMG
    return np.dstack([DMG,-1*HMG,ZMG]),metadata
