#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import os, timeit
import logbook
import numpy as np
import ovationpyme
import matplotlib.pyplot as pp
from geospacepy import satplottools
from collections import OrderedDict
import scipy.linalg as linalg
import h5py

from AMGeO.files.directories import tables_dir
from AMGeO.basis.functions import basis_functions_set as basisset

log = logbook.Logger('AMGeO.basis.eofs')

class AMGeOBasisFunctions(object):
    """ Pass as eof_basis in EmpiricalOrthogonalFunctionSet if
    the EOFs are tabulated in terms of full 244 basis functions
    """
    def __init__(self):
        self.n_basisvecs = basisset.n_basis

    def __call__(self):
        return np.ones((basisset.n_basis,basisset.n_basis),dtype=float)

class CuKp3PrincipalComponents(object):
    def __init__(self,n_pcs=50):
        self.n_pcs = n_pcs
        self.n_basisvecs = n_pcs
        #Now we find the eigenvectors of C_u
        self.basis_pc_eigvals,self.basis_pc_eigvecs = self._eof_basis()

    def _cu(self):
        """
        Loads Richmond and Kamide 1988 Covariance Matrix
        """
        cov_table_dir = os.path.join(tables_dir,'covariance')
        Cu = np.loadtxt(os.path.join(cov_table_dir,'cu_kp3'))
        return Cu

    def _eof_basis(self):
        """
        Performs Principle Component Analysis on AMGeO basis functions,
        via a precomputed covariance matrix C_u which was created for
        the original AMGeO procedure

        Returns n_eig eigenvectors associated with the largest n_eig eigenvalues of C_u

        These serve as a basis for expressing each EOF. Since these
        eigenvectors are principal components of the AMGeO basis set, they
        automatically contains a large portion of the variability in the AMGeO basis functions

        Also, since each eigenvector is effectively a set of weights or coefficients for
        the n_basis AMGeO basis functions, which we can find values for at an arbitrary location
        r, via the interpolation procedure shown in BasisFunctionSet.get_potential

        If:
          V_k
            is the length n_basis eigenvector associated with the k-th largest
            eigenvalue of the covariance matrix C_u ( k in [1,n_eig=50] ),
            with components V_k,n
            (the coefficient for the n-th AMGeO basis function (n in [1,n_basis = 244]))
          x_n(r)
            is the (scalar) value associated with the n-th AMGeO basis function
            evaluated at the location r (n in [1,n_basis = 244])

        Then the weight for the n-th AMGeO basis function for the EOF is:
            W_n = sum( beta_k*V_k,n ) where sum runs from k=1 to k=n_eig=50

        And the value of the EOF, evaluated at a location r_l, is the linear combination:
            EOF(r) = sum_n( W_n*x_n ) where the sum runs from n=1 to n=n_basis=244

        Note that C_u is n_basis x n_basis and represents the covariance
        of the basis set
        """
        n_eig = self.n_pcs
        Cu = self._cu()

        #The column v[:, i] is the normalized eigenvector corresponding to the eigenvalue w[i].
        #Since covariance matrices are by definition symmetric we can get eigs with a
        #specific function (for general matices use np.linalg.eig)
        #Eigen vectors come out in order of INCREASING size, and with degenerate eigenvectors repeated
        w,v = np.linalg.eig(Cu)
        wsort = np.argsort(w)[::-1]

        #i_highest = np.arange(len(w)-1,n_eig-1,-1) #Return in decreasing order (highest eigenvalue first)

        return w[wsort][:n_eig],v[:,wsort][:,:n_eig]

    def __call__(self):
        return self.basis_pc_eigvecs

class EmpiricalOrthogonalFunctionSet(object):
    """
    A class representing a set of empirical orthogonal functions
    expressed as coefficient vectors for AMGeO basis functions.

    Exists to enforce convention on shape of the arrays (alphas/betas),
    and also to remove ambiguity about whether EOFs are expressed as 
    coeffs of the 50 PCs of Richmond and Kamide covariance matrix,
    or as coeffs of the 244 AMGeO/AMIE basis functions.
    """
    def __init__(self,n_eofs,eof_basis,truncate=False):
        """

        Parameters
        ----------
        n_eofs - int
            Number of EOFs expected when loading files
        eof_basis - AMGeOBasisFunctions or CuKp3PrincipalComponents instance
            Object which returns transformation matrix from AMGeO basis
            function to EOF basis functions
        truncate - bool,optional
            Default False, a ValueError is raised if more than
            than n_eofs are found when loading EOFs from a file.
            If True, will silently truncate EOF time and spatial coefficients
            (alphas and betas) to match expected number of EOFs

        """
        self.n_eofs=n_eofs # Use the first n_eofs most dominant eofs in expansions
        self._eof_basis_check(eof_basis)
        self.eof_basis = eof_basis
        self.truncate = truncate
        
        #Each alpha coefficient is a weight for a given EOF 
        #for a specific set of observations (which
        #are all associated with a single time)

        #Each beta coefficient for a given EOF is 
        #a weight for one of the eigenvectors of C_u

        #The alphas are required to express the EOF-based covariance, 
        #but only the betas are required
        #to express the EOFs themselves

        #Define variables allowed in the _data dictionary (accessible from
        #__getitem__ and __setitem__)

        self._meta = {
                      'mean':{
                               'expected_shape':(eof_basis.n_basisvecs,1),
                               'description':'Spatial mean coefficients',
                               'truncate_dims':None
                             },
                      'betas':{
                                'expected_shape':(eof_basis.n_basisvecs,n_eofs),
                                'description':'Spatial EOF coefficients',
                                'truncate_dims':[1]
                                },
                      'alphas':{
                                'expected_shape':(-1,n_eofs),
                                'description':'Time varying EOF coefficients',
                                'truncate_dims':[1]
                                },
                      'covdiag':{
                                'expected_shape':(n_eofs,n_eofs),
                                'description':'Diagonal of EOF covariance',
                                'truncate_dims':[0,1]
                                }}

        self._data = OrderedDict()
            
        self.eof_basis_vectors = eof_basis()

    @staticmethod
    def _eof_basis_check(eof_basis):
        valid_types = [AMGeOBasisFunctions,CuKp3PrincipalComponents]
        if not any([isinstance(eof_basis,t) for t in valid_types]):
            log.debug('{} is not a valid eof_basis, valid: {}'.format(eof_basis,
                                                                     valid_types))
    @staticmethod
    def _is_expected_shape(arr,expected_shape):
        """Compares an array's shape tuple to an expected shape tuple,
        with -1 in the expected_shape meaning any length along that dimension
        """
        return all([(nel1==nel2 or nel2==-1) for nel1,nel2 in zip(arr.shape,expected_shape)])

    def _settable_check(self,key):
        """Only items with an entry in _meta are settable with the dictionary
        syntax"""
        if key not in self._meta:
            raise ValueError(('Tried to set {},'.format(key)
                              +'try one of {}'.format([key for key in self._meta])))

    def _shapecheck(self,arr,metakey):
        meta = self._meta[metakey]
        arrdesc = '{} ({}) array'.format(meta['description'],metakey)
        if not self._is_expected_shape(arr,meta['expected_shape']):
            errstr = (arrdesc+' had shape {},'.format(arr.shape)
                     +' expected ({})'.format(meta['expected_shape'])
                     +' (-1 means any length)')
            raise ValueError(errstr)

    def _truncate(self,arr,metakey):
        meta = self._meta[metakey]
        trunc_arr = arr.copy()
        if meta['truncate_dims'] is not None:
            eofdims = meta['truncate_dims']
            for eofdim in eofdims:
                #clumsy way of forming a slice
                slc = []
                for idim in range(len(arr.shape)):
                    if idim == eofdim:
                        slc.append(range(self.n_eofs)) #Equiv to :self.n_eofs
                    else:
                        slc.append(slice(None)) #Equiv to :
                trunc_arr = trunc_arr[tuple(slc)]
            log.debug('Reshaped {} from {} to {}'.format(metakey,
                                                    arr.shape,
                                                    trunc_arr.shape)) 
        return trunc_arr

    def __setitem__(self,key,arr):
        self._settable_check(key)
        try:
            self._shapecheck(arr,key)
        except ValueError:
            if self.truncate:
                arr = self._truncate(arr,key)
            else:
                raise
        self._data[key]=arr

    def __getitem__(self,key):
        return self._data[key]

    # def load_from_text(self,filename,key,transpose=False):
    #     """Directly load EOF coefficients (alphas or betas) from a text file"""
    #     raw_coeffs = np.genfromtxt(filename)
    #     self[key]=raw_coeffs.T if transpose else raw_coeffs

    # def load_from_h5(self,h5fn,datasetname,key,transpose=False):
    #     """Directly load EOF coefficients (alphas or betas) from an HDF5
    #     dataset"""
    #     with h5py.File(h5fn,'r') as h5f:
    #         raw_coeffs = h5f[datasetname][:]
    #     self[key]=raw_coeffs.T if transpose else raw_coeffs

    def load_alpha_beta_from_files(self,alpha_file,beta_file):
        """
        Directly load alpha and beta coefficients from ASCII
        files. This is how alpha and beta are handled in the original
        MATLAB version of AMGeO

        both files named by alpha_file and beta_file
        must have self.n_eofs columns (3 by default)

        alpha_file - str
            valid ASCII filename
            May have any number of rows (weight of each
            of the 3 EOFs for a particular time)

        beta_file - str
            ASCII filename. Must have self.n_eig rows, each representating the
            weights for each of the
            n_eig (50 by default) most important PCs of Richmond and Kamide
            covariance matrix Cu

        """
        self['alphas'] = np.genfromtxt(alpha_file)
        self['betas'] = np.genfromtxt(beta_file)
    
    def load_amgeo_eof_h5(self,h5fn):
        """
        Load alpha and beta coefficients from HDF5 file generated by AMGeO_EOF
    
        Parameters
        ----------

        h5fn - str
            Full path to EOF file

        """
        with h5py.File(h5fn,'r') as h5f:
            self['alphas'] = h5f['alphas'][:]
            self['betas'] = h5f['beta_arr'][:]
            self['mean'] = h5f['beta_mean'][:]

    # def plot_eofs(self,filename=None):
    #     basis = self.amgeobasis
    #     bf_vals = basis.get_potential(basis.lat_grid.flatten(),basis.lon_grid.flatten()) #grid_lats only goes down to ithtrns (transfer colat)
    #     X,Y = satplottools.latlon2cart(basis.lat_grid.flatten(),basis.lon_grid.flatten(),'N')
    #     X_grid,Y_grid = X.reshape(basis.lat_grid.shape),Y.reshape(basis.lat_grid.shape)

    #     f = pp.figure(figsize=(4*(self.n_eofs+1),4))
    #     for i_eof in range(self.n_eofs):
    #         ax = pp.subplot(1,self.n_eofs+1,i_eof+1)
    #         B = np.dot(self.basis_pc_eigvecs,self.betas[:,i_eof])
    #         eof_grid = np.dot(bf_vals,B).reshape(X_grid.shape)
    #         satplottools.draw_dialplot(ax)
    #         ax.contour(X_grid,Y_grid,eof_grid,20,lw=4)
    #         ax.text(-40.,-40,'Min: %.1f \nMax: %.1f' % (np.nanmin(eof_grid.flatten()),
    #                                                 np.nanmax(eof_grid.flatten())))

    #     #Bottom Row
    #     ax = pp.subplot(1,self.n_eofs+1,self.n_eofs+1)
    #     colors=['r','g','b']
    #     for i_eof in range(self.n_eofs):
    #         ax.plot(self.alphas[:,i_eof],colors[i_eof]+'o',label='EOF%d' % (i_eof))
    #     ax.set_ylabel('Alphas')
    #     ax.legend()

    #     pp.subplots_adjust(left=.05,right=.95,top=.95,bottom=.05,hspace=.05,wspace=.05)

    #     f.savefig('eofs_plot.png' if filename is None else filename)



