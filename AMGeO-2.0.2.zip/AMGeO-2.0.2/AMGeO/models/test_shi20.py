#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import numpy as np
from numpy import testing as nptest
from AMGeO.models import shi20

@pytest.mark.parametrize('hemisphere',('N','S'))
@pytest.mark.parametrize('kind',('all','cme','hss','slw'))
def test_can_load(hemisphere,kind):
    eofs = shi20.Shi20EOFSet(hemisphere,kind)