#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration

import numpy as np
import os
import matplotlib.pyplot as pp

from AMGeO.files.directories import tables_dir
from AMGeO.basis.eofs import EmpiricalOrthogonalFunctionSet
from AMGeO.models.shi20 import Shi20EOFSet

cov_table_dir = os.path.join(tables_dir,'covariance')

class EOFBasedCovariance(object):
	"""
	EOF based covariance as in Equation 15 of Matsuo et. al., 2015
	"""
	def __init__(self,empirical_orthogonal_function_set):
		"""
		Hand load the alpha and beta files
		"""
		self.EOFbasis = empirical_orthogonal_function_set

		# Could be PCs of Richmond and Kamide Cu matrix, or just
		# array of ones indicating the EOFs are stored in terms of 
		# AMGeO basis functions
		eof_basis_vectors = self.EOFbasis.eof_basis_vectors

		alpha_all = self.EOFbasis['alphas']
		beta_all = self.EOFbasis['betas']

		d = alpha_all**2

		#Calculate the 'C sub gamma' diagonal matrix
		#which here is approx as the mean of the square of all alphas for each
		#EOF along the diagonal
		Cg = np.zeros((self.EOFbasis.n_eofs,self.EOFbasis.n_eofs))
		for i_eof in range(self.EOFbasis.n_eofs):
			#Only use alpha values below the 95th percentile in mean
			not_outliers = d[:,i_eof]<=np.nanpercentile(d[:,i_eof],95)
			Cg[i_eof,i_eof] = np.nanmean(d[not_outliers,i_eof])

		#print str(Cg)
		# Convert beta from Cu principal components to AMGeO basis functions
		# (First 3 EOFs times 50 highest eigenvalues (by default))
		B = np.dot(cu_pcs,beta_all)

		#Covariance
		self.prior_model_covariance = np.dot(B,np.dot(Cg,B.T))

	def __call__(self):
		return self.prior_model_covariance

class AmieCuKp3Covariance(object):
	"""
	This is the simplest possible prior model error covariance model
	it simply loads the Richmond and Kamide error covariance from a
	table
	"""
	def __init__(self):
		#Load the 244x244 covariance matrix that was the original one used for AMGeO
		self.prior_model_covariance = np.loadtxt(os.path.join(cov_table_dir,'cu_kp3'))
		#self.prior_model_covariance = .5e11 * self.prior_model_covariance
		self.prior_model_covariance = 1.0e11 * self.prior_model_covariance
		#Magic number .5e11 from ground magnetometer matlab amgeo...has to do with
		#units of electric potential?
		#I'm guessing that the cu_kp3 has units of kV**2, since Var(X) = Expectation((X-mu)**2)
		#then the unit conversion would be (1000 V/kV)...where the other .5e5 comes from I have no idea

class CS10Covariance(object):
	"""
	This is the covariance matrix constructed from 30 EOFs of the residuals:
	Residuals = (superDARN observations - CS10 Model Output).
	This is Ellen Cousins' work to characterize the deviations of the model
	from observations and thus the model error
	"""
	def __init__(self):
		# Get coefficients that define EOFs
		coeff_dir = os.path.join(tables_dir,'cs10')
		coeff_fn = os.path.join(coeff_dir,'sam_eof_coeffs.dat')
		if not os.path.exists(coeff_fn):
			raise IOError('EOF coefficients file %s not found' % (coeff_fn))

		with open(coeff_fn,'r') as f:
			eof_coeffs = np.loadtxt(coeff_fn)

		eof_coeffs=eof_coeffs.transpose()

		(nbasis,neof) = eof_coeffs.shape

		#Construct EOF covariance matrix
		# (diagonal matrix with variance defined by power law:
		#  C[n,n] = a*n^-b , with
		#  power-law parameters a = 80 kV^2, b = 1)
		apl = 80.*1e6 #kV -> V
		bpl = 1.
		n = np.arange(neof)+1
		eof_var = apl*n**(-bpl)
		eof_cov = np.diag(eof_var)
		eof_cov_inv = np.diag(1./eof_var)

		#Prior model error covariance in terms of AMGeO basis functions
		self.prior_model_covariance = np.dot(np.dot(eof_coeffs,eof_cov),np.transpose(eof_coeffs))

	def __call__(self):
		return self.prior_model_covariance

class Shi20Covariance(object):
	"""
	The covariance matrix appropriate for toroidal magnetic potential
	and field aligned currents constructed from the first 10 EOFs of Yining Shi's
	2019 PhD work and 2020 papers
	"""	
	def __init__(self,shi_20_eof_set):
		
		if not isinstance(shi_20_eof_set,Shi20EOFSet):
			raise TypeError(('Input should be type {}'.format(type(Shi20EOFSet))
				             +'not {}'.format(type(shi_20_eof_set))))

		eofs = shi_20_eof_set.eofset

		self.prior_model_covariance = np.dot(eofs['betas'],
											np.dot(eofs['covdiag'],
													eofs['betas'].T))

	def __call__(self):
		return self.prior_model_covariance