#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
import os

from AMGeO.basis.grid import grid
from AMGeO.models import cs10

from geospacepy import special_datetime

class PotentialTable(object):
    """A fixed value 'model' which has the same interface as other
    electric potential models (e.g. CS10), but just loads an ASCII
    table of potential values on the standard AMGeO grid.

    Note that expects longtiude to vary across rows in table
    and latitude across columns

    Attributes
    ----------
    name : str
        String indicating what model this object represents
    pot : np.ndarray
        2D array of electric potential from file
        shape=(n_mlats=36,n_mlons=24)
    basisset : amgeo_obs.BasisFunctionSet
        Basis function object
    mlats : np.ndarray
        2D array of magnetic latitudes of grid
        shape=(n_mlats=36,n_mlons=24)
    mlons : TYPE
        2D array of AMGeO magnetic longitudes (MLT in deg)
        of grid, shape=(n_mlats=36,n_mlons=24)
    """
    def __init__(self,tablefile):
        self.name = 'WeimerTable'
        self.pot = np.genfromtxt(tablefile) #Wiemer dataset is 37 x 25

        n_mlats = grid.shape[0]
        n_mlons = grid.shape[1]

        print("Table shape %s" % (str(self.pot.shape))
                +"expected shape %d lats, %d lons" % (n_mlats,n_mlons))

        #Cut off a row and column to make dimensions match :-(
        if self.pot.shape[0] == n_mlons+1:
            self.pot = self.pot[1:,1:].T

        if self.pot.shape[0] != n_mlats:
            raise ValueError('Shape of potential array'
                            +'from file %s' % (tablefile)
                            +'is wrong '
                            +'(expected %d rows(lats) ' % (n_mlats)
                            +'got %d)!' % (self.pot.shape[0]))


        # 90-transfer latitude
        # (where basis function become trig not spherical harm)
        self.mlats = grid.lat_grid
        self.mlons = grid.lon_grid

    def __call__(self,dt,hemisphere,mlats,mlons):
        """Return the electric potential array reshaped to match
        the shape of input mlats and mlons arrays.

        Parameters
        ----------
        dt : datetime.datetime
            Date and time for model run (usused, here to satisfy model
            __call__ interface standard)
        hemisphere : str,['N' or 'S']
            Hemisphere to run model for (usused, here to satisfy model
            __call__ interface standard)
        mlats : np.ndarray
            Magnetic latitudes
        mlons : np.ndarray
            AMGeO magnetic longitudes (MLT in degrees)

        Returns
        -------
        pot : np.ndarray
            Electric potential values from table reshaped
            to match mlats array shape
        """
        return self.pot.reshape(mlats.shape)

class CS10ElectricPotential(object):
    """The Cousins and Shepard 2010 Electric Potential Model (AMGeO Native)

    Attributes
    ----------
    name : str
        Description

    .. note::
        Just SAM package is used to get access to this model

    """
    def __init__(self,startdt,enddt,silent=True):
        """Create a CS10 object

        Parameters
        ----------
        startdt : datetime.datetime
            The earliest time for which we would
            expect to get the conductance
        enddt : datetime.datetime
            The latest time for which we would
            expect to get the potential
        """
        #
        self.name = 'CS10'
        self.startdt, self.enddt = startdt, enddt

        #Load complete set of CS10 model coefficients
        #in advance to speed up loop
        self.model = cs10.CS10(silent=silent)

        #Average over 45 min, delay IMF data (shift older data to newer times)
        #                       by 10 mins to account for propagation
        IMFdelay = 10
        IMFave   = 45
        self.driver = cs10.cs10_driver(startdt,enddt,
                                            delay_mins=IMFdelay,
                                            avg_mins=IMFave)

    def _check_hemisphere(self,hemisphere):
        if hemisphere not in ['N','S']:
            raise ValueError('Hemisphere is not N or S')

    def _check_datetime(self,dt):
        if dt < self.startdt or dt > self.enddt:
            dtfmt = '%Y%m%d %H:%M'
            raise ValueError('Datetime {}'.format(dt.strftime(dtfmt))
                                +'is out of range '
                                +'{}-{}!'.format(self.startdt.strftime(dtfmt),
                                                 self.enddt.strftime(dtfmt)))


    def _get_solarwind(self,dt):
        omind,vsw,By,Bz,Esw,cang,tilt = self.driver.get_conditions(dt)
        return omind,vsw,By,Bz,Esw,cang,tilt

    def __call__(self,dt,hemisphere,mlats,mlons):
        """Take arrays (1D or 2D) of mlats and mlons
        and return array of electric potential of same shape

        Parameters
        ----------
        dt : datetime.datetime
            Date and time to run model for
        hemisphere : str or None,optional
            Hemisphere we are getting the potential for
        mlats : np.ndarray
            Array of magnetic latitudes
        mlons : np.ndarray
            Array of AMGeO magnetic longitudes (MLT in degrees)

        Returns
        -------
        mod_pot : np.ndarray
            Array of electric potential model values

        Raises
        ------
        ValueError
            If sign of latitude array and hemisphere selection are
            inconsistant
        """


        self._check_datetime(dt)
        self._check_hemisphere(hemisphere)

        if hemisphere is 'N' and np.nanmean(mlats)<0.:
            raise ValueError('Negative latitudes detected,'
                            +'but hemisphere is set to N')

        mlats = np.abs(mlats)

        omind,vsw,By,Bz,Esw,cang,tilt = self._get_solarwind(dt)

        mlt_lons = mlons

        mod_pot = self.model(mlats,mlt_lons,hemisphere,
                            Esw,cang,tilt)

        mod_pot = mod_pot.reshape(mlats.shape)

        return mod_pot
