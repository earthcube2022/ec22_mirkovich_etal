import pytest
from datetime import date, datetime
from AMGeO.controllers.controller import Controller, amgeo_date_to_date_and_hemi

@pytest.fixture
def controller():
    # setup
    controller = Controller(None)
    yield controller
    # teardown
    controller = None

@pytest.mark.controller
def test_get_date_and_hemi():
    s = '20130507N'
    assert(amgeo_date_to_date_and_hemi(s) == (date(2013, 5, 7), 'N'))
    s = '20091231S'
    assert(amgeo_date_to_date_and_hemi(s) == (date(2009, 12, 31), 'S'))

@pytest.mark.controller
def test_parse_date_args_date(controller: Controller):
    d = controller._parse_date_args(date(2013, 4, 5))
    assert(len(d['20130405']) == 1339)

@pytest.mark.controller
def test_parse_date_args_datetime(controller: Controller):
    d = controller._parse_date_args(datetime(2013, 4, 5, 1, 30, 55))
    assert(len(d['20130405']) == 1)

@pytest.mark.controller
def test_parse_date_args_list(controller: Controller):
    d = controller._parse_date_args([
        datetime(2011, 1, 1, 1, 30, 0),
        datetime(2011, 1, 2, 1, 30, 0),
        datetime(2011, 1, 2, 2, 30, 0)
    ])
    assert(len(d['20110101']) == 1)
    assert(len(d['20110102']) == 2)

@pytest.mark.controller
def test_parse_date_args_list_with_date_datetime(controller: Controller):
    d = controller._parse_date_args([
        date(2011, 1, 1),
        datetime(2011, 1, 2, 1, 30, 0),
        datetime(2011, 1, 2, 2, 30, 0)
    ])
    assert(len(d['20110101']) == 1339)
    assert(len(d['20110102']) == 2)

@pytest.mark.controller
def test_parse_date_args_list_with_date_datetime(controller: Controller):
    d = controller._parse_date_args([
        date(2011, 1, 1),
        datetime(2011, 1, 2, 1, 30, 0),
        datetime(2011, 1, 2, 2, 30, 0)
    ])
    assert(len(d['20110101']) == 1339)
    assert(len(d['20110102']) == 2)

@pytest.mark.controller
def test_parse_date_args_error(controller: Controller):
    with pytest.raises(Exception) as e:
        controller._parse_date_args(1)
        assert(False)

@pytest.mark.controller
def test_parse_date_args_list_error(controller: Controller):
    with pytest.raises(Exception) as e:
        controller._parse_date_args([
            date(2011, 1, 1),
            datetime(2011, 1, 2, 1, 30, 0),
            4
        ])
        assert(False)

@pytest.mark.controller
def test_parse_date_args_date_unpack(controller: Controller):
    d = controller._parse_date_args([
        date(2011, 1, 1)
    ], unpack_day=False)
    assert(d['20110101'] == date(2011, 1, 1))