from datetime import datetime, date
import datetime as datetime_module
import h5py as h5
import os
from typing import Tuple

def format_date(d: date or datetime, h=None) -> str:
    if h:
        s = '{}{:02d}{:02d}{}'.format(d.year, d.month, d.day, h)
    else:
        s = '{}{:02d}{:02d}'.format(d.year, d.month, d.day)
    return s

def amgeo_date_to_date_and_hemi(s: str) -> Tuple[date, str]:
    # NOTE: transforms a amgeo string of date
    year = int(s[0:4])
    month = int(s[4:6])
    day = int(s[6:8])
    hemi = s[8]
    d = date(year, month, day)
    return d, hemi

def amgeo_datetime_to_datetime(s: str) -> datetime:
    """Transforms an AMGeO datetime to a python datetime

    Parameters:
    ----------
    s : str
        An AMGeO h5 file datetime ('YYYYMMDD_HHMMSS')
    """
    year = int(s[0:4])
    month = int(s[4:6])
    day = int(s[6:8])
    hour = int(s[9:11])
    minute = int(s[11:13])
    second = int(s[13:15])
    dt = datetime(year, month, day, hour, minute, second)
    return dt

def get_datetimes(d: date) -> list:
    startdt = datetime(d.year,d.month,d.day,0,2,30)
    center_datetimes = [startdt + datetime_module.timedelta(minutes=i*5) for i in range(1339)]
    return center_datetimes

class Controller:

    def __init__(self, amgeo_api):
        """Base AMGeO Controller class, meant to be extended. See default_controller
        """
        self.amgeo_api=None
        self.type=None
        pass

    def __repr__(self) -> str:
        return '%s AMGeO Controller' % self.type

    def _get_output_dir(self) -> str:
        """Shared method to get the current output directory
        """
        return self.amgeo_api.get_output_dir() + '/' + self.type


    def _parse_date_args(self, date_args: date or datetime or list or tuple, unpack_day=True) -> dict:
        """Shared method to parse date arguments and return a dictionary of 
        the datetimes desired grouped by date

        Parameters
        ----------
        date_args : date or datetime or list or tuple
            A date argument in a supported form

        unpack_day : bool = True
            Optional argument that specifies wheter to unpack a given day argument into 5 min
            slices of datetimes throughout the day (True), or just leave the day as a date (False)
        """
        if (type(date_args) == date):
            if (unpack_day):
                return {
                    format_date(date_args): get_datetimes(date_args)
                }
            else:
                return {
                    format_date(date_args): date_args
                }
        elif (type(date_args) == datetime):
            return {
                format_date(date_args): [date_args]
            }
        elif (type(date_args) == list):
            groups = {}
            for el in date_args:
                if (type(el) == date):
                    if (unpack_day):
                        dts = get_datetimes(el)
                        groups[format_date(el)] = dts
                    else:
                        groups[format_date(el)] = el
                elif (type(el) == datetime):
                    s = format_date(el)
                    if s in groups and type(groups[s]) == list:
                        if el not in groups[s]:
                            groups[s].append(el)
                    else:
                        groups[s] = [el]
                else:
                    raise Exception('Date arg %s in list is invalid' % type(el))
            return groups 
        elif (type(date_args) == tuple):
            # TODO: need to get better idea of how this should work
            raise Exception('Date arg of type tuple is not yet supported')
        else:
            raise Exception('Date arg %s is invalid' % type(date_args))

    def generate(self, date_args, hemisphere):
        """Required method by extending controllers
        """
        raise NotImplementedError

    def browse(self, *browse_args) -> list:
        """Retruns information regarding the AMGeO maps that have been generated in 
        the current output direcotry.

        If no date is passed, will return a list of date/hemisphere tuples of dates 
        that AMGeO has data for

        Parameters
        ----------
            hemisphere : 'N' or 'S'
                Hemisphere in question that you would like to browse data for

            date_arg : date, optional
                Optionally pass date argument to provide verbose data information 
                in the form of specific datetimes for a specific date
        """
        hemi, date_arg = None, None
        if (len(browse_args) == 2):
            date_arg = browse_args[0]
            hemi = browse_args[1]
        else:
            hemi = browse_args[0]
            

        output_dir = self._get_output_dir()
        dates = os.listdir(output_dir)
        r = [] 
        # NOTE: if date arg, will return list of datetimes w/ hemi of specified date
        if date_arg:
            for d in dates:
                if d[-1] == hemi:
                    dt, _ = amgeo_date_to_date_and_hemi(d)
                    if (dt == date_arg):
                        f = h5.File(self._get_output_dir() + '/' + d + '/amgeo_v2_' + d + '.h5', 'r')
                        times = list(f.keys())[0:-2]
                        for t in times:
                            r.append(amgeo_datetime_to_datetime(t))
        # NOTE: else, just return if data exists for each date/hemi
        else:
            for d in dates:
                if d[-1] == hemi:
                    dt, _ = amgeo_date_to_date_and_hemi(d)
                    r.append(dt)

        return r

    def load(self, date_args, hemisphere):
        """Required method by extending controllers
        """
        raise NotImplementedError