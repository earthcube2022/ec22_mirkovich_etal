Installation Details
====================

AMGeO currently relies on several Python packages which are not on
PyPI, so they must be installed from Github. A requirements.txt
file is provided which can be used to install these depenancies using
pip.

.. code::

	pip install -r requirements.txt

.. note::

	AMGeO has been tested only on Ubuntu Linux, using Python 3 
	It is possible it will run other operating systems;
	we have tried to avoid version and OS-specific features 
	as much as possible, but no guarantees at this stage


Python
------

We recommend using Anaconda Python 3 (https://www.anaconda.com/distribution/#download-section). 

Fortran
-------

Some of the dependancies of AMGeO include Python wrappers of Fortran code.
Please ensure you have gfortran installed.

Dependancies
------------

Geospacepy-lite
---------------

Install from https://github.com/lkilcommons/geospacepy-lite

Apex-Python
-----------

Install from https://github.com/lkilcommons/apex-python

OvationPyme
-----------

Install from https://github.com/lkilcommons/OvationPyme
