AMGeO Coordinate System (:math:`[\hat{\phi},\hat{\theta},\hat{B}]`)
===================================================================

Relationship between AMGeO coordinates and geophysical directions:
------------------------------------------------------------------

Phi direction is same in both hemispheres:

.. math::
   \hat{\phi}_{N} = \hat{E}

.. math::
   \hat{\phi}_{S} = \hat{E}

Theta direction switches between hemispheres:

.. math::
   \hat{\theta}_{N} = -\hat{N}

.. math::   
   \hat{\theta}_{S} = \hat{N}

Vertical direction also switches:

.. math::
   \hat{B}_{N} = -\hat{U}
 
.. math::
   \hat{B}_{S} = \hat{U}
 
.. note::
   (vertical direction unit vector :math:`\hat{B}` points in same direction as the geomagnetic main field vector in both hemispheres)

SuperDARN Line of Sight Ion Drift Velocity
==========================================

SuperDARN :math:`\vec{v}_{LOS}` in ENU coordinates: 
---------------------------------------------------

.. math::
   \vec{v}=|v|sin(\beta)\hat{E}+|v|cos(\beta)\hat{N} + 0\hat{U}

( :math:`\beta` is the angle (east of north) of the line-of-sight vector)

SuperDARN :math:`\vec{v}_{LOS}` in AMGeO coordinates:
-----------------------------------------------------

Northern Hemisphere:
********************

.. math::
   \vec{v}=|v|sin(\beta)\hat{\phi}_{N}-|v|cos(\beta)\hat{\theta}_{N} + 0\hat{B}_{N}

Southern Hemisphere:
********************

.. math::
   \vec{v}=|v|sin(\beta)\hat{\phi}_{S}+|v|cos(\beta)\hat{\theta}_{S} + 0\hat{B}_{N}

SuperDARN Line of Sight Electric Field
======================================

In AMGeO Coordinates
--------------------

Northern Hemisphere:
********************
.. math::

   \vec{E} = -\vec{v} \times \vec{B}

Plug in velocity for this hemisphere:

.. math::

   \vec{E} = - \langle |v|sin(\beta),-|v|cos(\beta),0 \rangle \times \langle 0,0,|B| \rangle

Compute cross product (in Wolfram Alpha!):

.. math::

   \vec{E} = \langle |v||B|cos(\beta),|v||B|sin(\beta),0 \rangle

Express as vector sum:

.. math::

   \vec{E} = |v||B|cos(\beta)\hat{\phi}_{N} + |v||B|cos(\beta)\hat{\theta}_{N} + 0\hat{B}_{N}

Southern Hemisphere:
********************
.. math::

   \vec{E} = -\vec{v} \times \vec{B}

Plug in velocity for this hemisphere:

.. math::

   \vec{E} = - \langle |v|sin(\beta),|v|cos(\beta),0 \rangle \times \langle 0,0,|B| \rangle

Compute cross product (in Wolfram Alpha!):

.. math::

   \vec{E} = \langle -|v||B|cos(\beta),|v||B|sin(\beta),0 \rangle

Express as vector sum:

.. math::

   \vec{E} = -|v||B|cos(\beta)\hat{\phi}_{S} + |v||B|cos(\beta)\hat{\theta}_{S} + 0\hat{B}_{S}
 
   
