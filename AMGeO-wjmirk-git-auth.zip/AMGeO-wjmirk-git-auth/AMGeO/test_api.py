import pytest
import os
from AMGeO.api import AMGeOApi

output_dir = os.path.dirname(os.path.realpath(__file__)) + '/amgeo_test'

@pytest.fixture
def api():
    # setup
    api = AMGeOApi(config_name='test')
    prev_dir = api.get_output_dir()
    api.set_output_dir(output_dir)
    yield api
    # teardown
    api.set_output_dir(prev_dir)
    api = None

@pytest.mark.api
def test_api_get_output_dir(api: AMGeOApi):
    assert(api.get_output_dir() == output_dir)

@pytest.mark.api
def test_api_set_output_dir(api: AMGeOApi):
    api.set_output_dir('./test')
    assert(api.get_output_dir().split('/')[-1] == 'test')