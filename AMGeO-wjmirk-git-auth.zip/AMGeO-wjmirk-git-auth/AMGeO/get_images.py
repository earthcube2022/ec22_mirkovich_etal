#!/usr/bin/python

import h5py as h5
import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate
import os
import sys

# name of parent directory for all image data
map_name = 'amgeo_epot_images'

# method to convert polar coordinates of amgeo to cartesian grid
def get_cartesian_coords(lats, lons):
    points = []
    for i in range(0, 24):
        for j in range(0, 37):
            lam = lons[i][j] / 360 * 2 * np.pi - (np.pi / 2)
            phi = lats[i][j] / 180 * np.pi
            x = np.cos(phi) * np.cos(lam)
            y = np.cos(phi) * np.sin(lam)
            points.append([x, y])
    points = np.array(points)
    return points[:,0], points[:,1]

# get the electric potentials at a specific time
def get_epots(epots):
    z = []
    for i in range(0, 24):
        for j in range(0, 37):
            z.append(epots[i][j])
    return np.array(z)

# create a plot of the interpolated data, and save as image
def create_image(x, y, z, output_dir, sample_name):
    # set image parameters
    min_x = min(x)
    max_x = max(x)
    min_y = min(y)
    max_y = max(y)
    x_range = np.linspace(min_x, max_x, num=200)
    y_range = np.linspace(min_y, max_y, num=200)
    new_x, new_y = np.meshgrid(x_range, y_range)
    
    # interpolation based on data
    rbf = interpolate.Rbf(x, y, z, function='linear')
    new_z = rbf(new_x, new_y)

    # generae plot
    fig, ax = plt.subplots(figsize=(8,8))
    plt.scatter(new_x, new_y, c=new_z, cmap='coolwarm')
    plt.gca().set_axis_off()
    plt.subplots_adjust(top = 1, bottom = 0, right = 1, left = 0, 
                hspace = 0, wspace = 0)
    plt.margins(0,0)
    plt.gca().xaxis.set_major_locator(plt.NullLocator())
    plt.gca().yaxis.set_major_locator(plt.NullLocator())

    # save image
    plt.savefig(output_dir + '/' + sample_name + '_epot_map.png', bbox_inches = 'tight', pad_inches = 0)

def main(amgeo_output, output_dir):
    days = os.listdir(amgeo_output)
    output_dir = output_dir + '/' + map_name
    try:
        os.stat(output_dir)
    except:
        os.mkdir(output_dir)
    for day in days:
        new_dir = output_dir + '/' + day
        try:
            os.stat(new_dir)
        except: 
            os.mkdir(new_dir)
        with h5.File(amgeo_output + day + '/' + 'amgeo_v1_' + day + '.h5', 'r') as f:
            samples = list(f.keys())
            samples.remove('lats')
            samples.remove('lons')
            lats = np.array(f['lats'])
            lons = np.array(f['lons'])
            x, y = get_cartesian_coords(lats, lons)
            for sample in samples:
                epots = f[sample]['epot']
                z = get_epots(epots)
                create_image(x, y, z, new_dir, sample)

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
