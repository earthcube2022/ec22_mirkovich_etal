
from apexpy import Apex
import numpy as np
#Create an Apex conversion instance at the usual reference altitude
#no epoch is specified; we will set the epoch just-in-time when we are going to
#do an coordinate transformation
apex_reference_height = 110000. # Apex reference height in meters
module_Apex = Apex(refh=apex_reference_height/1000.)

def update_apex_epoch(dt):
    year = dt.year
    doy = dt.timetuple().tm_yday
    epoch = year+doy/(366. if np.mod(year,4)==0 else 365.)
    print('Setting Apex epoch for {} to {}'.format(dt.strftime('%Y%m%d'),epoch))
    module_Apex.set_epoch(epoch)
