#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
import os,datetime
from collections import OrderedDict
import h5py

class MissingRequiredMetadataError(Exception):
    pass

class RecordMetadata(object):

    _required_attr_names = ['shortname','longname','units']

    def __init__(self,*required_attrs,**additional_attrs):
        self._meta=OrderedDict()
        self._add_attributes_from_constructor(required_attrs,additional_attrs)

    @classmethod
    def from_existing(cls,record_metadata,**amendments_or_additional_attrs):

        required_attrs = []
        for name in cls._required_attr_names:
            existing_attr = record_metadata[name]
            if name in amendments_or_additional_attrs:
                attr_suffix = amendments_or_additional_attrs[name]
            else:
                attr_suffix = ''
            required_attrs.append(existing_attr+attr_suffix)

        # additional_attrs = {}
        # for name in amendments_or_additional_attrs:
        #     if name not in cls.required_attrs:
        #         additional_attrs[name]=amendments_or_additional_attrs[name]

        new_record_metadata = cls(*required_attrs)

        for name in record_metadata:
            if name not in new_record_metadata:
                new_record_metadata[name]=record_metadata[name]

        return new_record_metadata

    def copy(self):
        return RecordMetadata.from_existing(self)

    def __eq__(self,other):
        if isinstance(other,RecordMetadata):
            return self._meta == other._meta
        else:
            raise TypeError('{} is not type RecordMetadata'.format(other))

    def __ne__(self,other):
        return not(self==other)

    def amended_copy(self,**required_attr_amendments):
        return RecordMetadata.from_existing(self,**required_attr_amendments)

    def __getitem__(self,attrname):
        return self._meta[attrname]

    def __setitem__(self,attrname,attrval):
        self._meta[attrname]=attrval

    def __iter__(self):
        for attrname in self._meta:
            yield attrname

    def __contains__(self,attrname):
        return attrname in self._meta

    def _add_attributes_from_constructor(self,required_attrs,additional_attrs):
        for attrname,attrval in zip(self._required_attr_names,required_attrs):
            self[attrname]=attrval
        for attrname,attrval in additional_attrs.items():
            self[attrname]=attrval

    def _check_required(self):
        for required_attrname in self._required_attr_names:
            if required_attrname not in self._meta:
                raise MissingRequiredMetadataError(('Missing required metadata:'
                                                    +str(required_attrname)))

    def _to_h5(self,h5dataset):
        self._check_required()
        for attrname,attrval in self._meta.items():
            h5dataset.attrs[attrname]=attrval

    def _from_h5(self,h5dataset):
        for attrname,h5attr in h5dataset.attrs.items():
            #h5attrs are always a list for some reason
            attrvals = h5attr[:]
            self[attrname]= attrvals[0] if len(attrvals)==1 else attrvals
        self._check_required()

class Record(object):
    """
    A Record stores data
    that is serializable to/from HDF5. Ideally the contents
    of a record should be sufficient for creating plots
    and doing basic analysis
    """
    def __init__(self,data,record_metadata):
        self.data = data
        self._meta = record_metadata

    def __getitem__(self,attrname):
        return self._meta[attrname]

    def __setitem__(self,attrname,attrval):
        self._meta[attrname]=attrval

    def _to_h5(self,h5varname,h5group):
        h5dataset = h5group.create_dataset(h5varname,data=self.data)
        self._meta._to_h5(h5dataset)

    def _from_h5(self,h5dataset):
        self._data = h5dataset[:]
        self._meta._from_h5(h5dataset)

if __name__=='__main__':
    pass


# class AmgeoAssimilationResultRecord(object):

#   def __init__(self,asim_result):
#       self._records = OrderedDict()
#       self.asim_result = asim_result

#   def _add_asim_output_var(self,varname,asim_attr,longname,units):
#       vardata = getattr(self.asim_result,asim_attr)
#       varattrs = {'longname':longname,'units':units}
#       self._add_output_var(varname,vardata,**varattrs)


#   'lat_grid','Apex latitude','degrees')
#   'lon_grid','Apex MLT in degrees','degrees')
#   'model_pot','Model electric potential','V')
#   'predicted_pot','AMGeO electric potential','V')
#   'error_pot','Electric potential analysis error','V')
#   'predicted_v_th','AMGeO anti-poleward ion convection','m/s')
#   'predicted_v_ph','AMGeO eastward ion convection','m/s')
#   'error_v_th','Anti-poleward ion convection analysis error','m/s')
#   'error_v_ph','Eastward ion convection analysis error','m/s')
#   'predicted_Qj','AMGeO Joule heating','W')
#   'hall_conductance','Model Hall conductance (euv+auroral+bkg)','S')
#   'pedersen_conductance','Model Ped conductance (euv+auroral+bkg)','S')
#   'average_electron_energy','Model average electron energy','keV')
#   'total_electron_energy_flux','Model total electron energy flux','ergs/cm^2/s')
#   'estimated_hemispheric_power','Integral of Model Total Energy Flux','W')
#   'cusp_mlat','Magnetic latitude of cusp model Frey(2003)','degrees')
#   'cusp_mlt','Magnetic local time of cusp model Frey(2003)','hours')

