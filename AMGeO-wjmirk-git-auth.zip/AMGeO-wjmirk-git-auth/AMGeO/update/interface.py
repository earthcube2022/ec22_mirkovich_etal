#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from collections import OrderedDict
from AMGeO.update.predict import MappingCollection,PredictionCollection,ResidualCollection
from AMGeO.update.assimilate import OperatorOnGrid,OperatorFromObservations

class Solver(object):
    """Produces predictions of BasisPhysicsFunctions on the grid
    """
    def __init__(self,background_model,covariance_model):
        self._mappings = MappingCollection(background_model,covariance_model)

    def append(self,basis_physics_function):
        self._mappings.append_from_target(OperatorOnGrid(basis_physics_function))

    def __iter__(self):
        for mapping in self._mappings:
            yield mapping

    def __call__(self,dt,hemisphere,observations_collection):
        """Do predictions for all mappings on the grid
        """
        prediction_collection = self._mappings(dt,hemisphere,observations_collection)
        return prediction_collection

class Validator(object):
    """Produces residuals from observations by predicting the observed quantity
    at the observations locations and computing the difference between
    observed and predicted
    """
    def __init__(self,solver):
        self._observations = []
        self._mappings = MappingCollection.from_existing(solver._mappings)

    def append(self,observations):
        self._observations.append(observations)
        self._mappings.append_from_target(OperatorFromObservations(observations))

    def __call__(self,dt,hemisphere,observations_collection):
        residual_collection = ResidualCollection(dt,hemisphere)
        prediction_collection = self._mappings(dt,hemisphere,observations_collection)
        for prediction,observations in zip(prediction_collection,self._observations):
            residual_collection.append_from_prediction(prediction,observations)
        return residual_collection



