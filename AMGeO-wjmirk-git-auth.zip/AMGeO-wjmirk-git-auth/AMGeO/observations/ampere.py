# Copyright 2020, The Regents of the Univsersity of Colorado, a Body
# Corporate
from collections import OrderedDict
import logbook
import numpy as np
from geospacepy.special_datetime import (doyarr2datetime,
                                        datetimearr2jd,
                                        datetime2jd,
                                        datetime2doy,
                                        jdarr2datetime)

from geospacepy.terrestrial_spherical import (eci2ecef,
                                            ecef_cart2spherical,
                                            ecef_spherical2cart,
                                            ecef2enu)
from geospacepy.terrestrial_ellipsoidal import ecef_cart2geodetic
from geospacepy.satplottools import latlon2cart
# from apexpy import Apex
import datetime, os, timeit, random
from netCDF4 import Dataset
from collections import OrderedDict
from AMGeO.files.directories import tables_dir,data_dir
from AMGeO.datamodel.record import RecordMetadata
from AMGeO.basis.physics import (get_magnetic_perturbations,
                                _2D_components)
from AMGeO.basis.interface import ApexBasisPhysicsFunction
from AMGeO.basis.apex import module_Apex,update_apex_epoch

from AMGeO.downloaders.ampere import download_ampere_data

log = logbook.Logger('AMGeO.observations.ampere')

# #Create an Apex conversion instance at the usual reference altitude
# #no epoch is specified; we will set the epoch just-in-time when we are going to
# #do an coordinate transformation
# refh = 110.
# module_Apex = Apex(refh=refh)

class AmpereDatadict(object):
    """A general container for AMPERE data"""
    def __init__(self):
        self._observation_data = OrderedDict()
        self.minlat=40.

    def __setitem__(self,item,value):
        if len(value.shape)!=1:
            raise RuntimeError(('Items in AmpereDatadict must be flat'
                                +' {} had shape {}'.format(item,value.shape)))

        self._observation_data[item]=value

    def __getitem__(self,item):
        return self._observation_data[item]

    def __contains__(self,item):
        return item in self._observation_data

    def __iter__(self):
        for item in self._observation_data:
            yield item

    def items(self):
        for key,value in self._observation_data.items():
            yield key,value

    def _time_bounds_str(self):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (self['dts'][0].strftime(dtfmt),
                            self['dts'][-1].strftime(dtfmt))
        return tstr

    def _window_time_bounds_str(self,startdt,enddt):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (startdt.strftime(dtfmt),
                            enddt.strftime(dtfmt))
        return tstr

    def _get_time_mask(self,startdt,enddt):
        """Return mask in data arrays for all
        data in interval [startdt,enddt)"""
        startjd = datetime2jd(startdt)
        endjd = datetime2jd(enddt)
        if endjd<np.nanmin(self['jds']) or startjd>np.nanmax(self['jds']):
            dts = (startdt,enddt)
            raise ValueError(('Data required for: '
                              +self._window_time_bounds_str(*dts)
                              +'out of range for object: '
                              +self._time_bounds_str()))
        inrange = np.logical_and(self['jds']>=startjd,
                                    self['jds']<endjd)
        return inrange

    def _get_hemisphere_mask(self,hemisphere):
        if hemisphere not in ['N','S','both']:
            return ValueError(('{}'.format(hemisphere)
                              +' is not a valid hemisphere (use N,S or both)'))
        if hemisphere=='N':
            inhemi = self['lats'] > self.minlat
        elif hemisphere=='S':
            inhemi = self['lats'] < -1*self.minlat
        elif hemisphere=='both':
            inhemi = np.abs(self['lats']) > self.minlat
        return inhemi

    def _check_allowed_observers(self,allowed_observers):
        if not isinstance(allowed_observers,list):
            raise RuntimeError('allowed_observers must be a list of '
                               +'ampere pseudo vehicle numbers')
        for observer_id in allowed_observers:
            if observer_id not in self.observers:
                raise ValueError('Pseudo vehicle number {} not'.format(observer_id)
                                 +'in data PVNs \n({})'.format(self.observers))

    def _get_observers_mask(self,allowed_observers):
        if allowed_observers != 'all':
            self._check_allowed_observers(allowed_observers)

            observers_mask = np.zeros(self['jds'].shape,dtype=bool)
            for observer_id in allowed_observers:
                observers_mask = np.logical_or(observers_mask,
                                                self['observer_ids']==observer_id)
        else:
            observers_mask = np.ones(self['jds'].shape,dtype=bool)
            
        return observers_mask
    def _get_finite_mask(self):
        mask = np.logical_and.reduce((np.isfinite(self['data_eastward']), 
                                        np.isfinite(self['data_equatorward']), 
                                        np.isfinite(self['data_fieldaligned']))) 

        return mask

    def get_data_window_mask(self,startdt,enddt,hemisphere,allowed_observers):
        """Return a 1D mask into the data arrays for all points in the
        specified time range, hemisphere and with pseudo vehicle numbers
        from the list of PVNs allowed_observers"""
        mask = np.ones(self['jds'].shape,dtype=bool)
        mask = np.logical_and(mask,self._get_time_mask(startdt,enddt))
        mask = np.logical_and(mask,self._get_hemisphere_mask(hemisphere))
        mask = np.logical_and(mask,self._get_observers_mask(allowed_observers))
        mask = np.logical_and(mask,self._get_finite_mask())
        return mask

    def get_data_window(self,startdt,enddt,hemisphere,allowed_observers):

        mask = self.get_data_window_mask(startdt,
                                        enddt,
                                        hemisphere,
                                        allowed_observers)
        data_window = OrderedDict()
        for datavarname,datavararr in self.items():
            data_window[datavarname] = datavararr[mask]

        data_window_metadata = self._metadata.copy()
        data_window_metadata['window_startdt']=startdt
        data_window_metadata['window_enddt']=enddt
        data_window_metadata['window_allowed_observers']=allowed_observers

        return data_window,data_window_metadata

    @staticmethod
    def _rotate_eci_to_ecef(r_eci,B_eci,jds):
        """Rotate the position and magnetic perturbation data from
        Earth Centered Inertial to Earth Centered Earth Fixed
        """
        r_ecef = eci2ecef(r_eci,jds)
        B_ecef = eci2ecef(B_eci,jds)
        return r_ecef,B_ecef

    @staticmethod
    def _rotate_ecef_to_geographic(r_ecef,B_ecef):
        """Rotate the position and magnetic perturbation data from
        Earth Centered Intertial coordinates to geographic
        latitude,longitude,radius (for spacecraft positions),
        east, north, radial components (for magnetic perturbations)"""
        lats,lons,rs = ecef_cart2spherical(r_ecef)
        B_enu = ecef2enu(B_ecef,lats,lons)

        B_e = B_enu[:,0].flatten()
        B_n = B_enu[:,1].flatten()
        B_u = B_enu[:,2].flatten()
        return lats,lons,rs,B_e,B_n,B_u

    @staticmethod
    def _calculate_geodetic(gclats,glons,rs):
        #Convert to geodetic latitude
        R_ECEF = ecef_spherical2cart(gclats,glons,rs)
        gdlats,glons,heights_m = ecef_cart2geodetic(R_ECEF) # Expects units of meters
        #Convert heights to kilometers
        heights_km = heights_m/1000.
        #print(gdlats,glons,heights)
        return gdlats,glons,heights_km
    
    def _calculate_apex(self,years,doys,sods,gdlats,glons,heights_km,B_e,B_n,B_u):
        
        #Calculate datetimes
        decimal_doys = doys+sods/86400.
        dts = doyarr2datetime(decimal_doys,years)
         
        update_apex_epoch(dts[0]) #This does not need to be precise, time-wise
        
        #Calculate apex latitude and longitudes
        alats,alons = module_Apex.geo2apex(gdlats,glons,heights_km) 
        
        #Calculate magnetic local time from apex longitude
        mlts = np.full_like(alons,np.nan)
        for i in range(np.size(alons)):
            mlts[i] = module_Apex.mlon2mlt(alons[i],dts[i])

        #Calculate apex basis vectors
        #returns f1,f2,f3,g1,g2,g3,d1,d2,d3,e1,e2,e3
        basisvecouts = module_Apex.basevectors_apex(gdlats,glons,heights_km)
        #e1,e2,e3 = basisvecouts[-6],basisvecouts[-5],basisvecouts[-4]
        e1,e2,e3 = basisvecouts[-3],basisvecouts[-2],basisvecouts[-1]

        B_d1 = B_e*e1[0,:]+B_n*e1[1,:]+B_u*e1[2,:]
        B_d2 = B_e*e2[0,:]+B_n*e2[1,:]+B_u*e2[2,:]
        B_d3 = B_e*e3[0,:]+B_n*e3[1,:]+B_u*e3[2,:]

        return alats,alons,mlts,B_d1,B_d2,B_d3

class Ampere(AmpereDatadict):

    def __init__(self,dt,downsample_high_rate):
        """Create class instance for one day of raw ampere 
        magnetic perturbations.

        Parameters
        ----------

        dt - datetime.datetime
            Date of data to create class for
        downsample_high_rate - bool
            Controls whether data collected at AMPERE's high sampling rate
            is downsampled to match low sample rate
            when constructing a data_window.
        """
        AmpereDatadict.__init__(self)

        self.components = _2D_components
        self.dt = dt

        if not isinstance(downsample_high_rate,bool):
            raise TypeError('downsample_high_rate must be bool')

        self.downsample = downsample_high_rate

        self.basis_physics_function = ApexBasisPhysicsFunction(get_magnetic_perturbations)

        ncfn = os.path.join(data_dir,
                            'AMP_raw_dB_{}.nc'.format(dt.strftime('%Y%m%d')))

        if not os.path.exists(ncfn):
            download_ampere_data(dt.year,dt.month,dt.day)

        datatup = self._read_ncfile(ncfn)
        years,doys,hods = datatup[:3]
        satnum,satqual,planenum = datatup[3:6]
        r_eci,B_eci,sigma_B = datatup[6:9]

        self.observers = np.unique(satnum)
        
        dts = doyarr2datetime(doys+hods/24.,years)
        jds = datetimearr2jd(dts)
        sods = hods/24.*86400.

        r_ecef,B_ecef = self._rotate_eci_to_ecef(r_eci,B_eci,jds)
        gclats,glons,rs_m,B_e,B_n,B_u = self._rotate_ecef_to_geographic(r_ecef,B_ecef)
        gdlats,glons,heights_km = self._calculate_geodetic(gclats,glons,rs_m)
        alats,alons,mlts,B_d1,B_d2,B_d3 = self._calculate_apex(years,doys,sods,
                                                                gdlats,glons,heights_km,
                                                                B_e,B_n,B_u)
        
        self['dts'] = dts
        self['jds'] = jds


        self['lats'] = alats
        # self['lons'] = alons
        self['lons'] = mlts/12*180
        self['lts'] = mlts
        self['data_eastward'] = self['dBd1'] = B_d1
        self['data_equatorward'] = self['dBd2'] = B_d2
        self['data_fieldaligned'] = self['dBd3'] = B_d3
        #This copy fixes what we belive to have been an aliasing error
        self['errs_eastward'] = sigma_B.copy()
        self['errs_equatorward'] = sigma_B.copy()
        
        self['observer_ids'] = satnum

        self._metadata = RecordMetadata('dB',
                                        'Spacecraft Magnetic Perturbations',
                                        'nT',
                                        validmin=-3000.,
                                        validmax=3000.,
                                        typicalvalue=500.)

    def _time_bounds_str(self):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (np.nanmin(self['dts']).strftime(dtfmt),
                            np.nanmax(self['dts']).strftime(dtfmt))
        return tstr

    def _window_time_bounds_str(self,startdt,enddt):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (startdt.strftime(dtfmt),
                            enddt.strftime(dtfmt))
        return tstr

    def __str__(self):
        return 'Ampere {}'.format(self._time_bounds_str())

    @staticmethod
    def _downsample_datadict(datadict,metadata):
        oids = datadict['observer_ids']
        unq_oids = np.unique(oids)
        dsampd_datadict = OrderedDict()
        for datavar in datadict:
            if datavar=='jds' or datavar=='dts':
                continue
            old_times = datadict['jds']
            old_data = datadict[datavar]
            tmin,tmax = np.nanmin(old_times),np.nanmax(old_times)
            deltat = 20./86400 # 20 seconds in units of days
            tbins = np.arange(tmin,tmax,deltat)
            new_times_by_sat,new_data_by_sat = [],[]
            for oid in unq_oids:
                oid_mask=oids==oid
                sat_old_times = old_times[oid_mask]
                sat_old_data = old_data[oid_mask]
                bin_inds = np.digitize(sat_old_times,tbins)
                popd_bins = np.unique(bin_inds)
                sat_new_times,sat_new_data = [],[]
                for ibin in popd_bins:
                    new_t = np.nanmedian(sat_old_times[bin_inds==ibin])
                    new_data = np.nanmedian(sat_old_data[bin_inds==ibin,...])
                    sat_new_times.append(new_t)
                    sat_new_data.append(new_data)
                new_times_by_sat.append(np.array(sat_new_times))
                new_data_by_sat.append(np.array(sat_new_data))
            if 'jds' not in dsampd_datadict:
                dsampd_datadict['jds'] = np.concatenate(new_times_by_sat,axis=0)
                dsampd_datadict['dts'] = jdarr2datetime(dsampd_datadict['jds'])
            dsampd_datadict[datavar]=np.concatenate(new_data_by_sat,axis=0)
        return dsampd_datadict,metadata

    # @staticmethod
    # def _downsample_datadict(datadict,metadata):
    #     df = pd.DataFrame(datadict)
    #     deltat = 20./86400 # 20 seconds in units of days
    #     tbins = range(tmin,tmax,deltat)
    #     tbinlabls = [(tl+th)/2 for tl,th in zip(tbins[:-1],tbins[1:])]           
    #     df['tbin']=pd.cut(df['jds'],tbins,tbinlabls)
    #     binned_df = df.groupby('tbin').median()
    #     binned_datadict_lists = binned_df.to_dict(orient='list',into=OrderedDict)
    #     binned_datadict = OrderedDict()
    #     for varname,arr in binned_datadict_lists.items():
    #         print(varname,)
    #         binned_datadict[varname]=np.array(arr)
    #     return binned_datadict,metadata

    def get_data_window(self,startdt,enddt,hemisphere,allowed_observers):
        #We will overload get_data_window to apply downsampling
        _datadict,_metadata = AmpereDatadict.get_data_window(self,
                                                            startdt,
                                                            enddt,
                                                            hemisphere,
                                                            allowed_observers)
        
        if self.downsample:
            datadict,metadata = self._downsample_datadict(_datadict,_metadata) 
        else:
            datadict,metadata = _datadict,_metadata

        return datadict,metadata

    def get_obs_to_basis(self,startdt,enddt,hemisphere,allowed_observers):
        """

        Compute forward operator, H, a matrix with shape [n_obs,n_basis]
        which when (matrix) multiplied by a vector of AMGeO basis
        function weights,produces the trunctated expansion value for
        ground magntic perturbations at the locations of each of
        the n_obs observations

        Store H as a class property so that we don't have to recompute
        it if, for example,
        get_ingest_data is called more than once without changing
        datetime range (self.startdt and self.enddt),
        which determines which data gets selected by get_ingest_data

        Returns
        -------
        H : np.ndarray
            Forward operator
        Hmeta : RecordMetadata
            Metadata information about ground magnetic perturbations
        """
        
        datadict,metadata = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)
        
        lats = np.abs(datadict['lats']) #Basis functions expect positive
        lons = datadict['lons']

        dt = startdt + (enddt-startdt)/2
        H,Hmeta = self.basis_physics_function(dt,hemisphere,lats,lons)

        return H,Hmeta

    def get_ingest_data(self,startdt,enddt,hemisphere,allowed_observers):
        """Formats the observations in the correct way so that they can be
        ingested into AMGeO

        Returns
        -------
        lats : np.ndarray
            Absolute magnetic latitudes of observations
        lons : np.ndarray
            AMGeO magnetic 'longitudes' (MLT in degrees) of observations
        y : np.ndarray
            1D array of magnetic perturbation observations
            (North component first, then East, then Upward)
        y_var : np.ndarray
            1D array of uncertainies (variances) in magnetic perturbations
            (i.e. diagonal of observation error covariance matrix)
        obs_to_basis : np.ndarray
            1D array that represents magnetic perturbations as AMGeO basis
            function coefficients (same component order as above)
        ymeta : RecordMetadata
            Metadata information (including data window extra attributes)
        """

        datadict,metadata = self.get_data_window(startdt,
                                                    enddt,
                                                    hemisphere,
                                                    allowed_observers)

        #Format the vector measurements as a 1-D observation vector,
        #with each component as a seperate observation
        y = np.dstack([datadict['data_eastward'].reshape(-1,1),
                       datadict['data_equatorward'].reshape(-1,1)])

        #Format the error/variance vector similarly,
        #this will be the diagonal of C_b / R, representativeness/observation
        #covariance
        #Cousins et. al. 2015 number of observations scaling factor,
        #as used for AMPERE
        
        y_var = np.dstack([datadict['errs_eastward'].reshape(-1,1)**2,
                           datadict['errs_equatorward'].reshape(-1,1)**2])

        #Get H for magnetic perturbations
        H,Hmeta = self.get_obs_to_basis(startdt,enddt,
                                                hemisphere,allowed_observers)

        #Obs to basis is also called forward operator H
        #Order is East, Equatorward, Vertical/Field Aligned
        obs_to_basis = H

        #Locations for each vector component
        ylats = datadict['lats']
        ylons = datadict['lons']

        ymeta = metadata

        return np.abs(ylats),ylons,y,y_var,obs_to_basis,ymeta

    def plot_vectors(self,ax,startdt,enddt,hemisphere,allowed_observers,
                residual_collection=None,**kwargs):

        datadict,metadata = self.get_data_window(startdt,
                                                    enddt,
                                                    hemisphere,
                                                    allowed_observers)

        if residual_collection is not None:           
            lats = residual_collection['dB_th_res'].lats
            lons = residual_collection['dB_th_res'].lons
            dB_east = residual_collection['dB_ph_res']['predicted'].flatten()
            dB_eq = residual_collection['dB_th_res']['predicted'].flatten()

        else:   
            lats = datadict['lats']
            lons = datadict['lons']
            dB_east = datadict['data_eastward']
            dB_eq = datadict['data_equatorward']

        X,Y = latlon2cart(lats,lons,hemisphere)

        #-6 for zero of phi at -Y instead of +X b/c MLT
        #Calculate arrow directions for vector plot
        theta = (lons-90.)
        theta = np.radians(theta)

        eq_hat_x,eq_hat_y = np.cos(theta),np.sin(theta)
        east_hat_x,east_hat_y = -1.*np.sin(theta),np.cos(theta)

        #Convert vectors to cartesian from top-down polar
        dB_x = dB_east*east_hat_x + dB_eq*eq_hat_x
        dB_y = dB_east*east_hat_y + dB_eq*eq_hat_y

        if 'key_vector_magnitude' in kwargs:
            key_vec_mag = float(kwargs['key_vector_magnitude'])
        elif 'typicalvalue' in metadata:
            key_vec_mag = metadata['typicalvalue']
        else:
            key_vec_mag = 500.

        if 'color' in kwargs:
            color = kwargs['color']
        else:
            color = 'k'

        Q1 = ax.quiver(X, Y, dB_x, dB_y, 
                            color=color,
                            angles='xy',
                            scale_units='xy',
                            scale=key_vec_mag/10.,
                            alpha=.8,
                            headwidth=4.,
                            headlength=6.,
                            headaxislength=4.,
                            width=.003)

        ax.quiverkey(Q1,.75,0.05,key_vec_mag,'{} nT'.format(key_vec_mag))

    @staticmethod
    def _read_ncfile(ncfn):
        """Read in the netCDF contents. For some reason the netCDF
        library slice syntax ([:]) returns MaskedArrays without any mask,
        so turn into normal arrays. Also the typing in the netCDF is not
        consistant (some netCDF vars are float32 or int16, 
        some are float64 or int32) so just cast everything to 
        Python default precision to avoid potential precision issues later
        """
        ds = Dataset(ncfn)
        
        #We only want real (unspliced) data, so first extract the mask
        #so we can store only real data going forward

        #originally this is an int variable, but cast to bool since we will
        #use as mask
        is_real = np.array(ds.variables['data_splice'][:],dtype=bool)

        #Integer year
        year = np.array(ds.variables['year'][:],dtype=int)[is_real]
        #integer day of year (1-366)
        doy = np.array(ds.variables['doy'][:],dtype=int)[is_real]
        #time in units of fractional hours of day
        hod = np.array(ds.variables['time'][:],dtype=float)[is_real]
        #pseudo vehicle number
        satnum = np.array(ds.variables['pseudo_sv_num'][:],dtype=int)[is_real]
        #pseudo vehicle data quality, q: q<1.1 -> dB>35 nT, 1.1<q<1.5 -> dB>85 nT
        satqual = np.array(ds.variables['pseudo_sv_quality'][:],dtype=float)[is_real]
        #vehicle orbit plane number
        planenum = np.array(ds.variables['plane_num'][:],dtype=int)[is_real]
        #vehicle position in ECI coordinates in units of meters
        r_eci = np.array(ds.variables['pos_eci'][:],dtype=float)[is_real,:]
        #magnetic field perturbations in ECI coordinates in units of nano-Tesla
        B_eci = np.array(ds.variables['b_eci'][:],dtype=float)[is_real,:]
        #magnetic field uncertainty in units of nano-Tesla
        #(still from average of low latitude dB?)
        sigma_B = np.array(ds.variables['b_error'][:],dtype=float)[is_real]
        #data source, s: s=0 -> sample from interpolation of leading and 
        #trailing satellites, s=1 -> sample from actual satellite measurement
        ds.close()
        return year,doy,hod,satnum,satqual,planenum,r_eci,B_eci,sigma_B