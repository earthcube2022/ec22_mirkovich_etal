AMGeO API
===============

Full API documentation is still in progress.

This module specifies the standard options and API for
generating AMGeO results

For examples and a run through of the new API, please checkout our `AMGeO API Release Notebook <https://github.com/AMGeO-Collaboration/AMGeO-API-Release>`_

AMGeO API Class
---------------
.. autoclass:: AMGeO.api.AMGeOApi
	:members:

AMGeO Default Controller
------------------------
.. autoclass:: AMGeO.controllers.default_controller.DefaultController
	:members:
	:inherited-members:

AMGeO Default Driver 
--------------------
.. autoclass:: AMGeO.driver_default.DefaultDriver
	:members:

	.. automethod:: AMGeO.driver_default.DefaultDriver.__init__

	.. automethod:: AMGeO.driver_default.DefaultDriver.__call__

AMGeO Default Result
--------------------
.. autoclass:: AMGeO.driver_default.DefaultResult
	:members:

	.. automethod:: AMGeO.driver_default.DefaultResult.__init__

