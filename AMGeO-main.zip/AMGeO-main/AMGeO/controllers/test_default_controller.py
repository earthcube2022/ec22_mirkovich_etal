import pytest
import os
from shutil import rmtree
from datetime import date, datetime
from AMGeO.api import AMGeOApi
from AMGeO.controllers.default_controller import DefaultController

output_dir = os.path.dirname(os.path.realpath(__file__)) + '/amgeo_test'

@pytest.fixture(scope='module')
def controller():
    # setup
    api = AMGeOApi(config_name='test')
    prev_dir = api.get_output_dir()
    api.set_output_dir(output_dir)
    print(api.get_output_dir())
    controller = DefaultController(api)
    yield controller
    # teardown
    # TODO: check this
    rmtree(output_dir, ignore_errors=True)
    api.set_output_dir(prev_dir)

@pytest.fixture(scope='module')
def controller_with_data():
    # setup
    api = AMGeOApi(config_name='test')
    prev_dir = api.get_output_dir()
    api.set_output_dir(output_dir)
    print(api.get_output_dir())
    controller_with_data = DefaultController(api)
    controller_with_data.generate([
        datetime(2013, 1, 1, 12, 30, 0),
        datetime(2013, 1, 1, 13, 30, 0),
        datetime(2013, 1, 2, 12, 30, 0),
    ], 'N')
    yield controller_with_data
    # teardown
    rmtree(output_dir)
    api.set_output_dir(prev_dir)

@pytest.mark.default_controller
def test_generate_datetime(controller: DefaultController):
    controller.generate(datetime(2013, 1, 1, 12, 30, 0), 'N')
    assert('AMGeO_N_01012013_12_30.png' in os.listdir(output_dir + '/Default/20130101N'))

@pytest.mark.default_controller
def test_generate_list_datetimes(controller: DefaultController):
    controller.generate([
        datetime(2013, 1, 1, 12, 30, 0),
        datetime(2013, 1, 2, 12, 30, 0),
    ], 'N')
    assert('AMGeO_N_01012013_12_30.png' in os.listdir(output_dir + '/Default/20130101N'))
    assert('AMGeO_N_01022013_12_30.png' in os.listdir(output_dir + '/Default/20130102N'))

@pytest.mark.default_controller
def test_load_day(controller_with_data: DefaultController):
    ds = controller_with_data.load(date(2013, 1, 1), 'N')
    assert(len(ds['epot']) == 2)

@pytest.mark.default_controller
def test_load_datetime(controller_with_data: DefaultController):
    ds = controller_with_data.load(datetime(2013, 1, 1, 12, 30, 0), 'N')
    assert(len(ds['epot']) == 1)

@pytest.mark.default_controller
def test_load_list_datetimes(controller_with_data: DefaultController):
    ds = controller_with_data.load([
        datetime(2013, 1, 1, 12, 30, 0),
        datetime(2013, 1, 2, 12, 30, 0),
    ], 'N')
    assert(len(ds['epot']) == 2)

@pytest.mark.default_controller
def test_load_list_date_and_datetimes(controller_with_data: DefaultController):
    ds = controller_with_data.load([
        date(2013, 1, 1),
        datetime(2013, 1, 2, 12, 30, 0),
    ], 'N')
    assert(len(ds['epot']) == 3)