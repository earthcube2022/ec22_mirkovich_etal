from AMGeO.controllers.controller import Controller, amgeo_datetime_to_datetime as to_datetime
from AMGeO.driver_default import run_list
import h5py as h5
import numpy as np
from xarray import Dataset, DataArray
from tqdm.auto import trange
from datetime import date, datetime
from typing import Union

class DefaultController(Controller):

    def __init__(self, amgeo_api):
        """Default AMGeO Controller instance

        Creates Assimilative Maps using SuperMAG and SuperDARN observations

        Does not predict magnetic potential nor field-aligned current
        """
        self.amgeo_api = amgeo_api
        self.type = 'Default'

    def __repr__(self) -> str:
        return super().__repr__() +  \
            '\nCreates Assimilative Maps using SuperMAG and SuperDARN observations' + \
            '\nDoes not predict magnetic potential nor field-aligned current'


    def generate(self, date_arg: Union[date, datetime, list], hemisphere: str):
        """Generates AMGeO maps for the following date arguments and hemisphere

        Parameters
        ---------
            date_arg : date or datetime or list
                The date argument for which you would like to generate maps for. 
                Some examples:
                    1) A date => will generate maps for 5 min intervals for the entire day

                    2) A datetime => will generate a map for the given datetime

                    3) A list of dates/datetimes => will generate maps for all elements in the list

            hemisphere : 'N' or 'S'
                The hemisphere you would like to generate maps for
        """
        days = self._parse_date_args(date_arg)
        keys = list(days.keys())
        # NOTE: this looks nice in notebooks but not in console, should fix?
        print('Data requested for %s day(s)' % len(keys))
        for i in trange(len(keys)):
            run_list(days[keys[i]], hemisphere, self._get_output_dir())
        print('AMGeO complete')

    def load(self, date_arg: Union[date, datetime, list], hemisphere: str) -> Dataset:
        """Loads AMGeO maps for the following date arguments and hemisphere into an Xarray DataSet. 

        Parameters
        ----------
            date_arg : date or datetime or list
                The date argument for which you would like to generate maps for. 
                Some examples:
                    1) A date => will load maps for all times available in the given day

                    2) A datetime => will load the map for the given datetime

                    3) A list of dates/datetimes => will load maps for all elements in the list

            hemisphere : 'N' or 'S'
                The hemisphere you would like to generate maps for

        Returns
        -------
            amgeo_maps : xarray.Dataset
                An Xarray Dataset of the provided dates/datetimes on the specified hemisphere

        """
        days = self._parse_date_args(date_arg, unpack_day=False)

        datetimes = []

        # initial setup, don't want to get this information over and over again
        amgeo_file = list(days.keys())[0] + hemisphere
        f = h5.File(self._get_output_dir() + '/' + amgeo_file + '/amgeo_v2_' + amgeo_file + '.h5', 'r')
        times = list(f.keys())[0:-2]

        # NOTE: data types in dataset (epot, cond_hall, int_joule_heat, etc)
        data_types = list(f[times[0]])
        data = {}
        for d in data_types:
            data[d] = []
        attrs = {} 
        for d in data_types:
            a = {
                'description': d
            }
            for t in f[times[0]][d].attrs.keys():
                a[t] = f[times[0]][d].attrs[t]
            attrs[d] = a

        # lats and lons
        lats = []
        for i in np.array(f['lats']):
            lats.append(i[0])
        lats = DataArray(
            data=lats,
            dims=['lat'],
            attrs=f['lats'].attrs
        ) 

        lons = np.array(f['lons'])[0]
        lons = DataArray(
            data=lons,
            dims=['lon'],
            attrs=f['lons'].attrs
        ) 

        # NOTE: build data to be packaged
        for day in days.keys():
            amgeo_file = day + hemisphere
            f = h5.File(self._get_output_dir() + '/' + amgeo_file + '/amgeo_v2_' + amgeo_file + '.h5', 'r')

            times = list(f.keys())[0:-2]
            dts = [to_datetime(t) for t in times]

            if (type(days[day]) == date):
                # include all times, since we want to load entire day
                pass
            else:
                # prune unwanted times
                i = 0
                while i < len(times):
                    dt = dts[i]
                    if type(days[day]) == list and not (dt in days[day]):
                        times.pop(i)
                        dts.pop(i)
                    else:
                        i += 1

            for dt in dts:
                datetimes.append(dt)

            for d in data_types:
                if d != 'int_joule_heat':
                    for el in [f[key] for key in times]:
                        t = el[d][:]
                        data[d].append(t)
                else:
                    for el in [f[key] for key in times]:
                        t = el[d][:][0]
                        data[d].append(t)

        dataset = {}
        for d in data_types:
            if d != 'int_joule_heat':
                dataset[d] = DataArray(
                    data=data[d],
                    dims=['time', 'lat', 'lon'],
                    coords={
                        "time": datetimes,
                        "lat": lats,
                        "lon": lons
                    },
                    attrs=attrs[d]
                )
            else:
                dataset[d] = DataArray(
                    data=data[d],
                    dims=['time'],
                    coords={
                        "time": datetimes
                    },
                    attrs=attrs[d]
                )
            # make sure times are sorted
            dataset[d] = dataset[d].sortby(dataset[d].time)

        ds = Dataset(
            data_vars=dataset,
            attrs={
                "description": "AMGeO Assimilative Maps",
                "version": "v2_beta",
                "hemisphere": hemisphere
            }
        )
        return ds