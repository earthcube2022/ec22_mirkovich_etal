#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from AMGeO.update.assimilate import OperatorOnGrid

from AMGeO.update.interface import Solver

from AMGeO.basis.interface import BasisPhysicsFunction, ModelDependantBasisPhysicsFunction
from AMGeO.basis.physics import (get_electric_potential,
                                get_ion_velocity,
                                get_electric_field)
from AMGeO.basis.physics import get_ground_magnetic_perturbations

from AMGeO.basis.interface import ApexBasisPhysicsFunction
from AMGeO.basis.physics import (get_magnetic_potential,
                                 get_field_aligned_current,
                                 get_magnetic_perturbations)

from AMGeO.basis.grid import grid

from AMGeO.basis.physics import _2D_components,_3D_components

from AMGeO.models.interface import BackgroundModel,DirectBackgroundModel

class ElectricPotentialSolver(object):

    def __init__(self,electric_potential_model,covariance_model,conductance_model):

        background_model = BackgroundModel(electric_potential_model,
                                            BasisPhysicsFunction(get_electric_potential))

        self.solver = Solver(background_model,covariance_model)

        self.solver.append(BasisPhysicsFunction(get_electric_potential))

        for cmpnt_name in _2D_components:

            self.solver.append(
                                BasisPhysicsFunction(get_ion_velocity,
                                                     component_name=cmpnt_name)
                                )

            self.solver.append(
                                BasisPhysicsFunction(get_electric_field,
                                                     component_name=cmpnt_name)
                                )

        # for cmpnt_name in _3D_components:

        #     self.solver.append(
        #                 ModelDependantBasisPhysicsFunction(conductance_model,
        #                                                     get_ground_magnetic_perturbations,
        #                                                     component_name=cmpnt_name)
        #                 )

    def __call__(self,dt,hemisphere,observations_collection):
        """Do predictions for all mappings on the grid
        """
        prediction_collection = self.solver(dt,hemisphere,observations_collection)
        return prediction_collection

class MagneticPotentialSolver(object):

    def __init__(self,mpot_coefficent_callable,covariance_model):

        background_model = DirectBackgroundModel(mpot_coefficent_callable)

        self.solver = Solver(background_model,covariance_model)

        self.solver.append(BasisPhysicsFunction(get_magnetic_potential))
        self.solver.append(BasisPhysicsFunction(get_field_aligned_current))

        for cmpnt_name in _2D_components:

            self.solver.append(
                                ApexBasisPhysicsFunction(get_magnetic_perturbations,
                                                        component_name=cmpnt_name)
                                )

    def __call__(self,dt,hemisphere,observations_collection):
        """Do predictions for all mappings on the grid
        """
        prediction_collection = self.solver(dt,hemisphere,observations_collection)
        return prediction_collection

