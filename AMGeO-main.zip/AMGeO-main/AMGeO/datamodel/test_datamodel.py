from AMGeO.datamodel.interface import RecordCollection
from AMGeO.datamodel.record import Record,RecordMetadata
import pytest
import shutil,tempfile,os
import numpy as np
from numpy import testing as nptest
import h5py

@pytest.fixture
def hdf5_file(request):

    h5dir=tempfile.mkdtemp()
    h5fn = os.path.join(h5dir,'test.h5')

    def remove_temporary_dir():
        shutil.rmtree(h5dir)

    request.addfinalizer(remove_temporary_dir)

    return h5fn

@pytest.fixture
def metadata_instance():
    shortname = 'tst_meta'
    longname = 'this is a test metadata'
    units = 'furlongs'
    test_record_metadata = RecordMetadata(shortname,longname,units)
    return test_record_metadata

@pytest.fixture
def record_instance(metadata_instance):
    record_metadata = metadata_instance
    data = np.arange(10)
    record = Record(data,record_metadata)
    return record

@pytest.fixture
def record_collection_instance():
    meta1 = RecordMetadata('r1','Record 1, (0-9)','unitless')
    meta2 = RecordMetadata('r2','Record 2, (10-19)','unitless')

    record1 = Record(np.arange(10),meta1)
    record2 = Record(np.arange(10,20),meta2)

    record_collection = RecordCollection()
    record_collection['record1']=record1
    record_collection['record2']=record2
    return record_collection

def _all_required_attrs_match(ref_record_metadata,test_record_metadata):
    matches = []
    for attr_name in ref_record_metadata._required_attr_names:
        attrs_match = ref_record_metadata[attr_name]==test_record_metadata[attr_name]
        matches.append(attrs_match)
    return all(matches)

def test_metadata_has_right_units(metadata_instance):
    assert(metadata_instance['units']=='furlongs')

def test_metadata_attrs_can_be_added(metadata_instance):
    metadata_instance['non_required_attr']='benjamin'
    assert(metadata_instance['non_required_attr']=='benjamin')

def test_from_existing_classmethod_copies(metadata_instance):
    test_meta = metadata_instance
    other_meta = RecordMetadata.from_existing(test_meta)
    assert(_all_required_attrs_match(test_meta,other_meta))

def test_from_existing_classmethod_amends(metadata_instance):
    test_meta = metadata_instance
    amendment = '_amened'
    other_meta = RecordMetadata.from_existing(test_meta,shortname=amendment)
    assert(other_meta['shortname']==test_meta['shortname']+amendment)

def test_metadata_copy(metadata_instance):
    test_meta = metadata_instance
    copy_of_test_meta = test_meta.copy()
    assert(_all_required_attrs_match(test_meta,copy_of_test_meta))

def test_metadata_equality_magic_method(metadata_instance):
    test_meta = metadata_instance
    copy_of_test_meta = test_meta.copy()
    assert(test_meta==copy_of_test_meta)

def test_metadata_inequality_magic_method(metadata_instance):
    test_meta = metadata_instance
    amended_copy_of_test_meta = test_meta.amended_copy(shortname='_2')
    assert(test_meta!=amended_copy_of_test_meta)

def test_metadata_amended_copy(metadata_instance):
    test_meta = metadata_instance
    amendment = '_ammeded'
    amended_meta = test_meta.amended_copy(shortname=amendment)
    assert(amended_meta['shortname']==test_meta['shortname']+amendment)

def test_metadata_serialize(hdf5_file,metadata_instance):
    with h5py.File(hdf5_file,'a') as h5f:
        h5dataset = h5f.create_dataset('test_dataset',data=np.zeros((10,)))
        metadata_instance._to_h5(h5dataset)

    with h5py.File(hdf5_file,'a') as h5f:
        h5dataset = h5f['test_dataset']
        assert(h5dataset.attrs['units']==metadata_instance['units'])

def test_record_creation_works(record_instance):
    assert(record_instance.data[5]==5)

def test_record_getitem_gets_meta(record_instance,metadata_instance):
    assert(_all_required_attrs_match(metadata_instance,record_instance))

def test_record_serialize(hdf5_file,record_instance):
    with h5py.File(hdf5_file,'a') as h5_root_group:
        record_instance._to_h5('test_dataset',h5_root_group)

    with h5py.File(hdf5_file) as h5_root_group:
        assert(h5_root_group['test_dataset'][5]==5)

def test_record_collection_serialize(hdf5_file,record_collection_instance):
    with h5py.File(hdf5_file,'a') as h5_root_group:
        record_collection_instance._to_h5(h5_root_group)

    with h5py.File(hdf5_file,'a') as h5_root_group:
        dataset2 = h5_root_group['record2']
        assert(dataset2[5]==15)

