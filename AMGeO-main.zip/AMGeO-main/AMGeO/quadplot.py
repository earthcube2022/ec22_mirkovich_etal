#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.gridspec as gridspec
import matplotlib.image as mplimg
import datetime,os,traceback
import numpy as np

from geospacepy import satplottools
from AMGeO.files.directories import assets_dir
from AMGeO.basis.grid import grid
from AMGeO.plots import grid_data_contourf,prediction_contourf,draw_min_max

def _fig_axs():
    f = plt.figure(figsize=(11,10),dpi=150)
    nrow=18
    ncol=32
    gs = gridspec.GridSpec(nrow,ncol)

    dial_rows = 8
    center_r_spacer = 1
    dial_cols = 14
    center_c_spacer = 2
    cb_rows = dial_rows
    cb_cols = 1

    r_top_start = 0
    r_top_end = dial_rows

    r_bottom_start = dial_rows+center_r_spacer
    r_bottom_end = dial_rows+center_r_spacer+dial_rows

    c_cbl_start = 0
    c_cbl_end = cb_cols

    c_axl_start = cb_cols
    c_axl_end = cb_cols+dial_cols

    c_axr_start = cb_cols+dial_cols+center_c_spacer
    c_axr_end = cb_cols+dial_cols+center_c_spacer+dial_cols

    c_cbr_start = cb_cols+dial_cols+center_c_spacer+dial_cols
    c_cbr_end = cb_cols+dial_cols+center_c_spacer+dial_cols+cb_cols

    ax_cb1 = f.add_subplot(gs[r_top_start:r_top_end,c_cbl_start:c_cbl_end])
    ax1 = f.add_subplot(gs[r_top_start:r_top_end,c_axl_start:c_axl_end])
    ax2 = f.add_subplot(gs[r_top_start:r_top_end,c_axr_start:c_axr_end])
    ax_cb2 = f.add_subplot(gs[r_top_start:r_top_end,c_cbr_start:c_cbr_end])

    ax_cb3 = f.add_subplot(gs[r_bottom_start:r_bottom_end,c_cbl_start:c_cbl_end])
    ax3 = f.add_subplot(gs[r_bottom_start:r_bottom_end,c_axl_start:c_axl_end])
    ax4 = f.add_subplot(gs[r_bottom_start:r_bottom_end,c_axr_start:c_axr_end])
    ax_cb4 = f.add_subplot(gs[r_bottom_start:r_bottom_end,c_cbr_start:c_cbr_end])
    for ax in [ax1,ax2,ax3,ax4]:
        satplottools.draw_dialplot(ax)

    axs = [ax1,ax2,ax3,ax4]
    axcbs = [ax_cb1,ax_cb2,ax_cb3,ax_cb4]
    return f,axs,axcbs

def _logo(f):
    """Adds an axes on the top right of quadplot figure, returns Axes"""
    w,h = .12,.12
    logo_ax = f.add_axes([1.-w,1.-h,w,h])
    logo_ax.set_axis_off()
    logo_png = os.path.join(assets_dir,'logo_big.png')
    logo_ax.imshow(mplimg.imread(logo_png))
    return logo_ax

def _imf_clock(f,axs,By,Bz):
    """Add IMF clock angle polar plot in center of quadplot

    INPUTS
    ------
        f - Figure
            Matplotlib figure object
        axs - list,[ax1,ax2,ax3,ax4]
            List of all four matplotlib axes objects making up quad plot
            (to find their positions to determine )
        By - float
            IMF By component in nT
        Bz - float
            IMF Bz component in nT

    RETURNS
    -------
        imf_ax - Axes
            Matplotlib axes object on which IMF is drawn
    """

    [ax1,ax2,ax3,ax4] = axs

    a1lr = ax1.bbox._bbox.corners()[3]
    a2ll = ax2.bbox._bbox.corners()[1]
    a3ur = ax3.bbox._bbox.corners()[2]
    a4ul = ax4.bbox._bbox.corners()[0]

    cx_imf = (a1lr[0]+a2ll[0])/2
    cy_imf = (a1lr[1]+a3ur[1])/2
    w_imf,h_imf = .14,.14
    Bt = np.sqrt(By**2+Bz**2)
    ca = np.arctan2(Bz,By)
    imf_ax = f.add_axes([cx_imf-w_imf/2,cy_imf-h_imf/2,w_imf,h_imf],projection='polar')
    imf_ax.plot([ca,ca],[0,Bt],'b-',linewidth=1.5)
    imf_ax.set_thetagrids([0,90,180,270],labels=['$B_{y}$','$B_{z}$','',''])
    imf_ax.set_rgrids([5,10,15],labels=['','','$15nT$'])
    imf_ax.set_rlim([0,15])
    #imf_ax.set_facecolor('white')
    imf_ax.grid(color='black',linewidth=.5,alpha=.5)
    return imf_ax


def default_quadplot(prediction_collection,
                      cond_ped,cond_hall,joule_heat,
                      By,Bz,vsw,
                      supermag_observations=None,
                      superdarn_observations=None,
                      ampere_observations=None,
                      plotdir='/tmp/amgeo',logo=True):

    dt = prediction_collection.dt
    hemisphere = prediction_collection.hemisphere

    grid_lats = grid.lat_grid
    grid_lons = grid.lon_grid

    f,axs,axcbs = _fig_axs()
    ax1,ax2,ax3,ax4 = axs
    ax_cb1,ax_cb2,ax_cb3,ax_cb4 = axcbs

    #Constants used by plotting code
    min_cond = np.floor(np.nanpercentile(cond_ped,[10]))
    max_cond = np.ceil(np.nanmax(cond_hall))

    cond_levels = np.arange(min_cond+.01,
                            max_cond,2)
    alpha = .95

    mpbl1 = grid_data_contourf(ax1,cond_ped,
                                cmap='viridis',vmin=0.,vmax=max_cond,
                                alpha=alpha)

    f.colorbar(mpbl1,label='Pedersen Conductance $[Mho]$',cax=ax_cb1)
    ax_cb1.yaxis.set_label_position('left')
    ax_cb1.yaxis.set_ticks_position('left')

    mpbl2 = grid_data_contourf(ax2,cond_hall,
                                cmap='viridis',vmin=0.,vmax=max_cond,
                                alpha=alpha)

    f.colorbar(mpbl2,label='Hall Conductance $[Mho]$',cax=ax_cb2)

    if 'jfac' not in prediction_collection._shortnames:
        mpbl3 = grid_data_contourf(ax3,joule_heat,
                                    cmap='inferno',vmin=0.,vmax=20.,
                                    alpha=alpha)

        f.colorbar(mpbl3,label='Joule Heating $[mW/m^2]$',cax=ax_cb3)
        ax_cb3.yaxis.set_label_position('left')
        ax_cb3.yaxis.set_ticks_position('left')

    else:
        fac_levels = np.linspace(-1,1,10)
        mpbl3 = prediction_contourf(ax3,prediction_collection,'jfac',
                                    cmap='bwr',vmin=-1,vmax=1.,
                                    levels=fac_levels,
                                    alpha=alpha)
        
        f.colorbar(mpbl3,label='FAC $[uA/m]$',cax=ax_cb3)
        ax_cb3.yaxis.set_label_position('left')
        ax_cb3.yaxis.set_ticks_position('left')
        
    pot_levels = np.arange(-30,30,3)
    mpbl4 = prediction_contourf(ax4,prediction_collection,'epot',
                                cmap='bwr',vmin=-30,vmax=30.,
                                levels=pot_levels,
                                alpha=alpha)

    if supermag_observations is not None:
        supermag_observations.plot_vectors(ax4,dt,hemisphere,color='darkorange')
    if superdarn_observations is not None:
        superdarn_observations.plot_vectors(ax4,dt,hemisphere,color='green')
    if ampere_observations is not None:
        ampere_observations.plot_vectors(ax3,dt,hemisphere,color='blue')
    
    f.colorbar(mpbl4,label='Electric Potential $[kV]$',cax=ax_cb4)


    if logo:
        ax_logo = _logo(f)

    ax_imf = _imf_clock(f,axs,By,Bz)

    for ax in axs:
        ax.set_aspect(1)

    swstr = 'By: %.2f nT, Bz: %.2f nT, Solar Wind Speed: %.2f km/s' % (By,Bz,vsw)
    f.suptitle('Assimilative Mapping of Geospace Observations\n%s\n%s' % (
                                    dt.strftime('%m/%d/%Y %H:%M'),
                                    swstr))

    if not os.path.exists(plotdir):
        os.makedirs(plotdir)

    f.savefig(os.path.join(plotdir,'AMGeO_%s_%s.png' % (
                                hemisphere,
                                dt.strftime('%m%d%Y_%H_%M'))))
    plt.close(f)
