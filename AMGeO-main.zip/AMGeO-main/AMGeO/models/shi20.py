import os
import numpy as np
from AMGeO.files.directories import tables_dir
from AMGeO.basis.eofs import (AMGeOBasisFunctions,
                              EmpiricalOrthogonalFunctionSet)

class Shi20Files(object):
    _kinds = ['all','cme','hss','slw']
    def __init__(self,hemisphere,kind):

        if hemisphere not in ['N','S']:
            raise ValueError(('Invalid hemisphere value'.format(hemisphere)
                              +'valid values: "N", north or "S", south"'))
        
        north_or_south = 'north' if hemisphere == 'N' else 'south'

        if kind not in self._kinds:
            raise ValueError(('Invalid kind of EOF'
                              +' valid values: {}'.format(self._kinds)))

        eof_dir = os.path.join(tables_dir,'shi20',kind)

        self.meanfn = os.path.join(eof_dir,
                                'beta_mean_{}.dat'.format(north_or_south))
        self.betasfn = os.path.join(eof_dir,
                                'beta_all_{}.dat'.format(north_or_south))
        self.diagcovfn = os.path.join(eof_dir,
                                'alpha_cov_{}.dat'.format(north_or_south))


class Shi20EOFSet(object):
    def __init__(self,hemisphere,kind):
        #Shi20 EOFs are stored as coefficients of the full 244 basis functions
        #(instead of the 50 CuKp3 prinicpal components). We only use the 
        #first 10 EOFs (of 30 total)
        self.files = Shi20Files(hemisphere,kind)
        self.eofset = EmpiricalOrthogonalFunctionSet(10,
                                                    AMGeOBasisFunctions(),
                                                    truncate=True)
        self.eofset['mean']=np.genfromtxt(self.files.meanfn)
        self.eofset['betas']=np.genfromtxt(self.files.betasfn)
        self.eofset['covdiag']=np.genfromtxt(self.files.diagcovfn)
        
        
