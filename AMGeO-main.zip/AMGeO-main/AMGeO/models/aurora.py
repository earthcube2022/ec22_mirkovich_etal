#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
from logbook import Logger
import scipy,os,timeit
from geospacepy import special_datetime

log = Logger('AMGeO.models.aurora')

def empirical_cusp(hemi,By,Bz):
    """Calculate an approximate proton precipitation cusp location
    (for use in TIEGCM) using a relationship
    suggested by Thomas Immel of Berkely

    Parameters
    ----------
    By : float
        IMF By in nT
    Bz : float
        IMF Bz in nT
    Returns
    -------
    mlat : float
        magnetic latitude of cusp
    mlt : float
        magnetic longitude of cusp

    References
    ----------
    Frey, H. U., S. B. Mende, S. A. Fuselier, T. J. Immel,
    and N. Ostgaard (2003),
    Proton aurora in the cusp during southward IMF
    """

    if hemi == 'N':

        mlt = 12.6+0.12*By
        mlat = 73.8+0.45*Bz

    elif hemi == 'S':

        log.warning(('WARNING: Validity of southern hemisphere cusp not verified\n'
                    +'will return northern prediction with opposite By effect'))

        mlt = 12.6-0.12*By
        mlat = 73.8+0.45*Bz

    else:
        raise ValueError('hemi must be N or S not %s' % (hemi))

    #Because AMGeO expects longitude
    mlt_lon = mlt/12*180.

    return mlat,mlt_lon

def inverse_robinson(sigp,sigh,min_ped=None,min_hall=None):
    """Converts hall and pedersen conductance to mean energy and
    energy flux via Robinson formula

    Parameters
    ----------
    sigp : numpy.ndarray
        Pedersen conductance [S]
    sigh : numpy.ndarray
        Hall conductance [S]
    min_sigp : float,optional
        Pedersen conductance threshold, locations below which in
        sigp will be set to zero in energy flux / avg energy
        If None, no thresholding performed
    min_sigh : float,optional
        Hall conductance threshold, locations below which in
        sigh will be set to zero in energy flux / avg energy
        If None, no thresholding performed

    Returns
    -------
    eavg : numpy.ndarray
        Average electron precipitation energy assuming maxwellian
        via Robinson empirical formula [keV]
    eflux : numpy.ndarray
        Total electron precipitation energy flux assuming maxwellian
        [mW/m^2] == [ergs/cm^2/s]
    """
    eavg = ((1/.45)*sigh/sigp)**(1/.85)
    eflux = (((16.+eavg**2)/(40.*eavg))*sigp)**2

    if min_ped is not None:
        below_thresh_p = sigp<min_ped
        eflux[below_thresh_p] = 0.
        eavg[below_thresh_p] = 0.
    elif min_hall is not None:
        below_thresh_h = sigh<min_hall
        eflux[below_thresh_h] = 0.
        eavg[below_thresh_h] = 0.

    return eavg,eflux
