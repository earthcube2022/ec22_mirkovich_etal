#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import numpy as np
import os
from numpy import testing as nptest

from AMGeO.files.directories import tables_dir
from AMGeO.basis import physics

from AMGeO.basis.functions import basis_functions_set as basisset
from AMGeO.basis.grid import grid
import datetime 

#Where are the tables used in the tests
#(usually output from other AMGeO implementations IDL/Matlab)
test_table_dir = os.path.join(tables_dir,'test_amgeo_basis')

def to_phi_theta(H):
    H_ph = physics._component_array_from_3D_array(H,'eastward')
    H_th = physics._component_array_from_3D_array(H,'equatorward')
    return H_ph,H_th

def test_scalar_component_decorator():
    """
    """
    assert(physics.get_electric_potential._components is None)

def test_2D_component_decorator():
    """
    """
    assert(physics.get_electric_field._components == physics._2D_components)

def test_3D_component_decorator():
    """
    """
    assert(physics.get_ground_magnetic_perturbations._components == physics._3D_components)

def test_potential_same_as_just_sam():
    """
    Does amgeo_basis.BasisFunctionSet return same potential as just_sam.basis.eval_amgeo_pot?
    """
    #First 6 basis functions for a single location
    expected_H_pot = np.array([ -5.93852379e-03,  -3.01748061e-02,  -6.55147131e-02,
         -6.77200084e-02,   1.58382391e-02,   7.27993422e-02])

    lats,lons = np.array([70.]),np.array([100.])
    H_pot,H_pot_meta = physics.get_electric_potential(lats,lons)

    nptest.assert_allclose(H_pot[0,:6],expected_H_pot,atol=1e-14)

def test_electric_field_same_as_just_sam():
    """
    Does amgeo_basis.BasisFunctionSet return same potential as just_sam.basis.eval_amgeo_pot?
    """
    #First 3 basis functions for a single location
    expected_H_E_phi =  np.array([5.56835183e-08,   2.82938896e-07,   6.14309188e-07])
    expected_H_E_theta = np.array([2.15699566e-08,   8.19143638e-08,   9.06568624e-08])
    lats,lons = np.array([70.]),np.array([100.])

    H_E,H_E_meta = physics.get_electric_field(lats,lons)
    H_E_ph,H_E_th = to_phi_theta(H_E)

    nptest.assert_allclose(H_E_ph[0][:3],expected_H_E_phi,atol=1e-3)
    nptest.assert_allclose(H_E_th[0][:3],expected_H_E_theta,atol=1e-3)

def test_calc_potcoeff_to_groundmagcoeff_returns_same_as_fortran():
    """
    Does amgeo_basis.BasisFunctionSet calculate zfma,vfma the same
    as get_gmagbasis.f90?
    """
    #Load conductance from precomputed data files
    ped_file = os.path.join(test_table_dir,'grid_ped_783')
    hall_file = os.path.join(test_table_dir,'grid_hal_783')

    ithtrns = basisset.qmeta['ithtrns']

    cond_ped = np.zeros((basisset.qmeta['ithmx'],36))
    cond_hall = np.zeros((basisset.qmeta['ithmx'],36))
    cond_ped.fill(.1)
    cond_hall.fill(.1)

    cond_ped_az = np.transpose(np.loadtxt(ped_file,dtype=np.float64)) # Auroral Zone conductance
    cond_hall_az = np.transpose(np.loadtxt(hall_file,dtype=np.float64)) # Auroral Zone conductance

    #neglect first column and row because of off by one in FTRAN
    cond_ped[:ithtrns,:] = cond_ped_az[1:,1:]
    cond_hall[:ithtrns,:] = cond_hall_az[1:,1:]

    #Load desired test results from output data files of get_gmagbasis.f90
    z_file = os.path.join(test_table_dir,'zfma_0778_0788.dat')
    v_file = os.path.join(test_table_dir,'vfma_0778_0788.dat')
    t_file = os.path.join(test_table_dir,'tfma_0778_0788.dat')
    p_file = os.path.join(test_table_dir,'psfma_0778_0788.dat')
    zfma_ftran,vfma_ftran = np.loadtxt(z_file,dtype=np.float64),np.loadtxt(v_file,dtype=np.float64)
    tfma_ftran,psfma_ftran = np.loadtxt(t_file,dtype=np.float64),np.loadtxt(p_file,dtype=np.float64)

    #Generate zfma and vfma from AmiePy
    #By default nlons=36, but tabulated conductances are only evaluated for 35 (an off by one?)
    zfma,vfma,tfma,psfma = physics.calc_potcoeff_to_groundmagcoeff(cond_ped,cond_hall)
    #zfma,vfma,tfma,psfma = basisset.calc_potcoeff_to_groundmagcoeff_old(cond_hall=cond_hall,cond_ped=cond_ped,nlons=35)

    """
    f1 = pp.figure()
    f2 = pp.figure()

    a1,a2 = f1.add_subplot(111),f2.add_subplot(111)
    cmin,cmax = np.nanmin(vfma_ftran),np.nanmax(vfma_ftran)
    map1 = a1.imshow(vfma_ftran)
    map2 = a2.imshow(vfma)
    f1.colorbar(map1)
    f2.colorbar(map2)
    a1.set_title('Fortran')
    a2.set_title('Python')
    pp.show()
    """

    #Pick a small selection to test
    delta = zfma_ftran[30:40,30:40]-zfma[30:40,30:40]
    nptest.assert_allclose(vfma[:30,:30],vfma_ftran[:30,:30],atol=1e-8)

def test_get_magnetic_perturbations():
    """
    Does the physics function run for space based magnetic perturbation data?
    """
    lats,lons = np.array([70.,71.]),np.array([100.,101.])
    dt = datetime.datetime(2011,11,26)
    H,H_meta = physics.get_magnetic_perturbations(lats,lons,dt,'N')
    H_ph,H_th = to_phi_theta(H)

    #check if shapes are the same 
    assert (len(lats),244) == np.shape(H_ph)
    assert (len(lats),244) == np.shape(H_th)

def test_magnetic_potential_and_electric_potential_same():
    """
    Check that the electric potential and magnetic potential basis
    function representations are equal (on the grid)
    """
    lats,lons = grid.lat_grid.flatten(),grid.lon_grid.flatten()
    epot_grid,epot_meta = physics.get_electric_potential(lats,lons)
    mpot_grid,mpot_meta = physics.get_magnetic_potential(lats,lons)

    assert(mpot_grid==pytest.approx(epot_grid))

def test_get_field_aligned_current():
    """
    Does it run test
    """
    lats,lons = grid.lat_grid.flatten(),grid.lon_grid.flatten()
    jfac_grid,jfac_meta = physics.get_field_aligned_current(lats,lons)
    assert(jfac_grid.shape==(lats.size,244))

if __name__ == "__main__":
    #Run the tests
    pytest.main()
