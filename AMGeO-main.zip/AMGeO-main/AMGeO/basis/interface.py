#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
import functools

from AMGeO.basis.functions import basis_functions_set as basisset
from AMGeO.basis.physics import _component_array_from_3D_array
from AMGeO.basis.physics import _component_metadata_from_vector_metadata

class BasisPhysicsFunction(object):
    def __init__(self,physics_function,component_name=None):
        self.physics_function = physics_function
        self.component_name = component_name

    def __call__(self,dt,hemisphere,lats,lons):
        H,Hmeta = self.physics_function(lats,lons)
        if self.component_name is None:
            return H,Hmeta
        else:
            component_H = _component_array_from_3D_array(H,self.component_name)
            component_Hmeta = _component_metadata_from_vector_metadata(Hmeta,self.component_name)
            return component_H,component_Hmeta

class ApexBasisPhysicsFunction(object):
    """This class allows for the case where a basis physics function
    directly depends on the time and hemisphere for Apex coordinates 
    calculations which can't be factored out into a seperate function as in
    ModelDependantBasisPhysicsFunction
    """
    def __init__(self,physics_function,component_name=None):
        self.physics_function = physics_function
        self.component_name = component_name

    def __call__(self,dt,hemisphere,lats,lons):
        H,Hmeta = self.physics_function(lats,lons,dt,hemisphere)
        if self.component_name is None:
            return H,Hmeta
        else:
            component_H = _component_array_from_3D_array(H,self.component_name)
            component_Hmeta = _component_metadata_from_vector_metadata(Hmeta,self.component_name)
            return component_H,component_Hmeta

class ModelDependantBasisPhysicsFunction(object):
    """This class proxies for a physics function
    from the AMGeO.basis.physics module which requires
    the output of a model on the FULL lat/lon grid
    (i.e. including latitudes below the transfer latitude).
    This means this does not calculate the model results on the standard
    grid (from basis.grid), rather the grid made from
    basisset.lats and basisset.lons.
    """
    def __init__(self,model,physics_function,component_name=None):
        self.model = model
        self.physics_function = physics_function
        self.component_name = component_name

    def __call__(self,dt,hemisphere,lats,lons):
        lat_grid,lon_grid = np.meshgrid(basisset.abslats,basisset.lons,indexing='ij')
        model_outputs = self.model(dt,hemisphere,lat_grid,lon_grid)
        H,Hmeta = self.physics_function(lats,lons,*model_outputs)
        if self.component_name is None:
            return H,Hmeta
        else:
            component_H = _component_array_from_3D_array(H,self.component_name)
            component_Hmeta = _component_metadata_from_vector_metadata(Hmeta,self.component_name)
            return component_H,component_Hmeta

# class ObservationDependantBasisPhysicsFunction(object):
#     """This class proxies for a physics function
#     from the AMGeO.basis.physics module which requires data from
#     an observation object as part of transformation of the data
#     returned from a physics_function
#     """
#     def __init__(self,observations,physics_function,transformation_function):
#         self.observations = observations
#         self.physics_function = physics_function
#         self.transformation_function = transformation_function

#     def __call__(self,dt,hemisphere,*args):


