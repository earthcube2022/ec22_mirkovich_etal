#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import os, timeit
import numpy as np
import scipy.linalg as linalg
from sklearn import linear_model

import matplotlib.pyplot as pp
from geospacepy import satplottools
#import igrfpy

from AMGeO.files import directories

#An equivalent utility function to matlab's regress,
#implemented using scikit-learn
#used to regress onto basis functions
def regress(X,y,regression_type='ols'):
    """Multilinear least-squares regression (duplicating MATLAB's regress)

    Parameters
    ----------
    X : np.ndarray
        Columns of inputs
    y : np.ndarray
        Column of outputs
    regression_type : str, optional
        Type of regression to use (can only be 'ols' currently)

    Returns
    -------
    coef : np.ndarray
        Regression coefficients

    Raises
    ------
    ValueError
        If regression_type is not 'ols'
    """
    y_column = y.reshape((-1,1))

    #Ordinary Least Squares regression (probably what MATLAB uses)
    if regression_type=='ols':
        clf = linear_model.LinearRegression(fit_intercept=False)
    else:
        raise ValueError('Regression type %s' % (regression_type)
                        +'not recognized!')
    clf.fit(X,y_column)
    return clf.coef_

class BasisFunctionsSet(object):
    """
    A class representing n_basis AMGeO basis functions

    These basis functions are described in:
    Richmond and Kamide, 1988

    Legacy information about AMGeO Basis Functions (From Art Richmond's qgen.f):
    C
    C  This program generates the basis functions for AMGeO.
    C  Most of the program is in terms of co-latitude THETA (TH)
    C  ITHMX=45 is the equator, and implies that DLAT is 2 deg (90/45 = 2)
    C  ITHTRNS*DLAT is the transition co-latitude, below which the basis
    C    functions become smooth.  Was originally set to 17 (17*2=34, or 56 mlat)
    C  Changed in 4/91 to 23 to accomodate very active days.  23*2=46 or 44 mlat,
    C   or 23*1.67 = 38.3 or 51.7 mlat depending on what ITHMX is.
    C  ITHMX=54 means DLAT = 90/54 = 1.67 deg
    C  4/93:  To have basis funcs go down to 40 mlat, then ITHTRNS*DLAT = 50,
    C         ITHTRNS = 50 / 1.67 = 30.
    C  360 / MMX = minimum wavelength used.  360/10=36, 360/11=32.7, 360/12=30.
    C  In AMGeO, choose DLAT same as here, and choose DLON ~ min wavelenth / 3
    C  Generally, want ITHPLT of AMGeO to go down to 50 mlat, or ITHPLT*DLAT=40.
    C  For 196 coefs, DLAT=2, min_wavel=33, ITHPLT=20, and LONMX=24.
    C  For 244 coefs, DLAT=1.67, min_wavel=30, ITHPLT=24, and LONMX=36.
    C  4/93:  To have plots and basis funcs go down to 40 mlat, ITHPLT*DLAT=50,
    C   or for 244 coefs, DLAT=1.67, min_wavel=30, ITHPLT=30, and LONMX=36.
    C
    C  MMX = # of wave numbers in longitude
    C   MXNMX .GE. MMX+1
    C   NMX(M=0-MMX) = MXNMX - M   (i.e., NMX(MMX-0) = MXNMX to MXNMX-MMX)
    C   NQS = SUM(NMX)
    C   NQ = 2*NQS
    C   MCOEF = NQ - MXNMX = # of coefficients
    C   NCOEF = 2*MCOEF + 2
    C  MROW =
    C   KMX=MROW*2.
    C  ITHTRNS = colat of transition between high and low latitudes
    C

    We are using qset244.24, which has the following settings:
    C  The following dimensions are for 244 basis funcs, down to 52 deg:
    C  Parameters for 244 coefs, basis funcs to 51.7 mlat.  DLAT=90/54=1.67,
    C     min_wavel=360/12 = 30 deg  so  DLON ~ 30/3 = 10 deg or LONMX=36.
    C     PARAMETER (ITHMX=54,LONMX=36)
    C     PARAMETER (MMX=12,NQ=260,NQS=130,MXNMX=16,MCOEF=244,NCOEF=490)      PARAMS.40
    C     PARAMETER (MROW=60,KMX=120,ITHTRNS=24)                              PARAMS.42

    """
    def __init__(self,legacy_grid=False):
        """
            conductance_model - object, optional
                The conductance model to use for calculation of
                (equivalent) current from electric field, must support
                the following syntax:

                cond_ped,cond_hall = conductance_model.get_conductance(mlats,mlons)

                for 2D latitude and longitude arrays, returning same-shape 2D conductance arrays
        """
        self.n_basis = 244 

        self.bfcn_tables_path = os.path.join(directories.tables_dir,'amieqset')
        self.qmeta = self.read_qset_metafile()
        self.ibm,self.iem = self.read_qset_m_layout_file()
        self.ns,self.nmx,self.nss = self.read_qset_n_layout_file()
        self.q,self.dq = self.read_qset()
        self.vfmps,self.zfmps = self.read_groundmag_zfmps_vfmps()
        self.nnp1 = self.read_laplacian_factor_file() #shape=(244,)

        # Colatitues of original grid. These are a property of the
        # basis set
        # This colat array started initally at 1. Further checking against
        # the Fortran needs to be done to figure out what it should actually be,
        # since this colatitude array MUST be what the tabulated basis functions
        # were generated with for results to be correct.
        self.theta = np.arange(1.,self.qmeta['ithmx'])*self.qmeta['dth']
        self.abslats = 90.-np.degrees(self.theta)

        # The 'natural' longitudes (not a property of the basis set, but derived from it):
        # Longitudes spaced at close to the smallest resolution resolvable by
        # the f_m (azimuthal) portion of the basis set (i.e. there are as many
        # longitude points as sine or cosine cycles in the highest azimuthal resolution
        # basis function)
        # Historically, the longitude grid had duplicate values of 0. and 360.
        # this is still an option for creating output compatible with tools
        # which expect the original AMIE grid
        #self.lons = np.linspace(0.,360.,36)
        #This longitudes includes 360. because it's not used anywhere
        #in this class so there is no chance of accidental
        #double counting (calc_potcoeff_to_groundmagcoeff)
        #uses it's own longitudes. But is used by other classes and
        #plots look strange if you don't include 360.
        self.lons = np.linspace(0.,360.,37)

        self.phi = np.radians(self.lons)

        #Cache of potcoeff to groundmag coeff transformation matrices
        #Define them so we can check against them
        self.cached_cond_hall,self.cached_cond_ped = None,None
        self.cached_ZFMA,self.cached_VFMA,self.cached_PSFMA,self.cached_TFMA = None,None,None,None

    def _check_latitudes_are_positive(self,abslats):
        if np.any(abslats<0.):
            raise ValueError(('To avoid errors basis_functions does not allow '
                             +'negative latitudes as inputs. Negative latitudes '
                             +'correspond to colatitudes far beyond the '
                             +'transfer colatitude where values '
                             +'of the basis functions begin to tend toward 0 '
                             +'(decaying exponentials)'))

    def _check_arrays_are_flat(self,*arrays):
        if any([len(arr.shape)>1 for arr in arrays]):
            raise ValueError('This function only accepts flat arrays as inputs')

    def read_qset_metafile(self,fname='qset16ascii24424bf_4.dat'):
        """
        Read the file which contains the 'metadata' about the basis function
        set, such as maximum values and lengths. These values are single-value constants.
        """
        fname = os.path.join(self.bfcn_tables_path,fname)
        if not os.path.exists(fname):
            raise IOError("Unable to access 4th AMGeO basis function table file %s" % (fname))

        with open(fname,'r') as f4:
            data4 = f4.readline().split()

        #i theta max, length of colatitudes array (for qset244.24 ithmx=54)
        ithmx = int(data4[0])
        # ? (for qset244.24 mrow=60)
        mrow = int(data4[1])
        #K is normalization constant for basis function ? (qset244.24 kmx=120)
        kmx = int(data4[2])
        #Maximum 'm' value for basis function set
        #(m takes values in -mmx,-mmx+1,...,0,...,mmx-1,mmx) (12 for qset244.24)
        mmx = int(data4[3])
        #Total number of distinct m,n combinations (2*nqs)
        #(nqs = sum(mxnmx-|m|) for m in -mmx:mmx = 260 for qset244.24)
        nq = int(data4[4])
        #Total number of distinct |m|,n combinations (nqs/2) (130 for qset244.24)
        nqs = int(data4[5])
        #Maximum number of n values per m value, i.e. there are mxnmx n values for m=0 (16 for qset244.24)
        mxnmx = int(data4[6])
        #Index into array of colats at which basis functions go from Legendre (high lat) to Trigonetric (low lat) (24 for qset244.24)
        ithtrns = int(data4[7])
        #Step size in colatitude in radians (0.29089E-01 for qset244.24)
        dth = float(data4[8])
        qmeta = {'ithmx':ithmx,'mrow':mrow,'kmx':kmx,'mmx':mmx,'nq':nq,
                    'nqs':nqs,'mxnmx':mxnmx,'ithtrns':ithtrns,'dth':dth}
        return qmeta

    def read_qset_m_layout_file(self,fname='qset16ascii24424bf_2.dat'):
        """
        Read the table file which describes which basis function number (0-243)
        corresponds to each value of 'm',
        from -mmx to mmx, including zero (2*mmx+1) values,
        in equation 38 of Richmond and Kamide, 1988.
        """
        fname = os.path.join(self.bfcn_tables_path,fname)
        if not os.path.exists(fname):
            raise IOError("Unable to access 2nd AMGeO basis function table file %s" % (fname))

        with open(fname,'r') as f2:
            data2 = np.loadtxt(f2,dtype='int')

        #ibm[i] is starting index into q and dq of all of the n values
        #for m = i, iem[i] is the ending index

        ibm = data2[:,0]-1 #from 1-based to 0-based indexing
        iem = data2[:,1]-1

        return ibm,iem

    def read_qset_n_layout_file(self,fname='qset16ascii24424bf_3.dat'):
        """
        metadata file has following columns
        0. ns - row number in q of first n value for this m
        1. nmx - maximum number of n values for this m value (nmx = mxnms-|m|)
        2.
        for each value of m in [-mmx,-mmx+1,...,0,...,mmx-1,mmx]

        ns is important because it describes the real organization of dq and q arrays
        which is slightly tricky because all of the data for the basis functions
        for say m = 1 is intermingled with m = -1 in an alternating fasion. The
        following table attempts to describe how each successive row in q and dq
        associate with and m and n values for the basis functions

        row #, m, n
        -----------
        ns(1)+1,1,n(1)[0]  # NOTE: Check if -m is first or +m is first, not clear
        ns(1)+2,-1,n(1)[0]
        ns(1)+3,1,n(1)[1]
        ns(1)+4,-1,n(1)[1]
        ...
        ns(1)+2*nmx(1),1,n(1)[nmx(1)]
        ns(1)+2*nmx(1)+1,-1,n(1)[nmx(1)]

        where,
            ns - starting row for the block of rows which belong collectively to +m/-m
            n[i] - ith n value for +m/-m
            nmx - mxnmx-|m|, the number of n values for +m/-m
        """
        fname = os.path.join(self.bfcn_tables_path,fname)
        if not os.path.exists(fname):
            raise IOError("Unable to access 3rd AMGeO basis function table file %s" % (fname))

        with open(fname,'r') as f3:
            data3 = np.loadtxt(f3,dtype='int')

        ns  = data3[:,0]-1 #from 1-based to 0-based indexing
        nmx = data3[:,1]
        nss = data3[:,2]-1 #minus 1 for zero based indexing?

        return ns,nmx,nss

    def read_qset(self,fname='qset16ascii24424bf_1.dat'):
        """
        Load the precomputed basis functions values from an ASCII table.
        These basis sets were computed using very high floating point
        precision on a Cray supercomputer, which is why we use
        tabulated values instead of compute ourselves at this point

        For the qset244.24, this a 520 row, 55 column data matrix

        Each column represents values for one latitude in
            [90,90-1.67,90-2*1.67,...,54]

        The rows are divided into two sets of 260, the values for the
        basis functions first, and values for their derivatives WRT colatitude
        after.
        """
        # Set parameters
        # qset244.24
        # the following parameters are for 36 basis functions, down to 44deg
        # From A. Richmond, NCAR-HAO

        fname = os.path.join(self.bfcn_tables_path,fname)
        if not os.path.exists(fname):
            raise IOError("Unable to access primary AMGeO basis function table file %s" % (fname))

        with open(fname,'r') as f:
            data = np.loadtxt(f,dtype=np.float64)

        qmeta = self.read_qset_metafile()
        nq,ithmx = qmeta['nq'],qmeta['ithmx']

        q  = data[0:nq,1:ithmx+1]     # using 1:ithmx+1 rather than 0:ithmx+1
        dq = data[nq:2*nq,1:ithmx+1]  # to match bug in original code
        return q,dq

    def read_groundmag_zfmps_vfmps(self,fname_v='qsetz244_vfmps.dat',fname_z='qsetz244_zfmps.dat'):
        """
        Load the set of precomputed constants which are used in transforming the
        AMGeO basis function weights/coefficients which represent the expansion
        of electric potential (i.e. c_n^m) to those that can represent magnetic
        perturbations at the ground (in the D,H,Z directions).

        I have not yet been able to find a reference describing how these are computed
        but they depend only on the 'n' index in the AMGeO basis functions.
        There are 130 rows for each of these (16+15+14+...+4=130) (the number
        of n eigenvalues for each |m|, beginning with 16 values of n for m=0),
        in the qset244 version of these tables.

        vfmps table is for D and H (horizontal components of ground mag coord system)
        zfmps table is for Z (vertical component of ground mag basis coord system)

        Note that these were computed by a different FORTRAN code than
        the rest of the tables ( beginning with qsetascii24424 ).

        """

        fname_v = os.path.join(self.bfcn_tables_path,fname_v)
        fname_z = os.path.join(self.bfcn_tables_path,fname_z)

        if not os.path.exists(fname_v) or not os.path.exists(fname_z):
            raise IOError("Unable to access AMGeO basis function ground magnetic perturbation file %s and %s" % (fname_v,fname_z))

        with open(fname_v,'r') as f:
            data_v = np.loadtxt(f,dtype=np.float64)
        with open(fname_z,'r') as f:
            data_z = np.loadtxt(f,dtype=np.float64)

        return data_v,data_z

    def read_laplacian_factor_file(self,fname='nnp1.244.24'):
        """
        This table appears to be a factor for each basis function
        which allows the expression of the horizontal laplacian (del squared)
        of the basis function set. It has shape 1 x n_basis (244)
        """

        fname = os.path.join(self.bfcn_tables_path,fname)
        if not os.path.exists(fname):
            raise IOError("Unable to access AMGeO basis function laplacian file %s." % (fname))

        with open(fname,'r') as f:
            data = np.loadtxt(f,dtype=np.float64)

        return data

    def compute_f(self,mlon,mmx=None,derivative=False):
        """
        Computes the values of the azimuthal part of the AMGeO basis functions
        for an array of longitudes (phi):
            f_m(phi)
                = sqrt(2)cos(m*phi) m < 0
                = sqrt(2)sin(m*phi) m > 0

            for each m in [-mmx,-mmx+1,...,0,...,mmx-1,mmx]

        Converted from AMGeO FORTRAN originally by A. Richmond, NCAR-HAO
        where this was a subroutine called fcmp

        Inputs
            mlon - np.ndarray
                Longitude, in degrees
            mmx - int, optional
                Maximum value of m for AMGeO basis functions
                If not defined, use default mmx from qset
            derivatives - bool, optional
                Also return the derivative of f WRT longitude/phi

        Returns

            f - np.ndarray,shape=(2*mmx+1, len(mlon))
                Values of azimuthal component of basis functions
                at all longitudes, for all m
        """
        self._check_arrays_are_flat(mlon)

        # Internal function
        #
        # They are apparently built up with some kind
        # of recursive algorithm
        phi = np.radians(mlon)
        cp,sp = np.cos(phi),np.sin(phi)
        nlons = len(phi)

        if mmx is None:
            mmx = self.qmeta['mmx']

        fp = np.ndarray(shape=(mmx+1,nlons),dtype=np.float64)
        fm = np.ndarray(shape=(mmx+1,nlons),dtype=np.float64)

        fp[0,:] = 1.
        fm[0,:] = 1.
        fp[1,:] = np.sqrt(2)*sp
        fm[1,:] = np.sqrt(2)*cp

        for m in range(2,mmx+1):
            fp[m,:] = cp*fp[m-1,:] + sp*fm[m-1,:] # f for m > 0 at each of the nlont longitudes
            fm[m,:] = cp*fm[m-1,:] - sp*fp[m-1,:] # f for m < 0 at each of the nlont longitudes

        f = np.vstack((fm[mmx:0:-1,:],fp[0:mmx+1,:]))

        if not derivative:

            return f

        else:

            df = f.copy()
            ms = np.arange(-mmx,mmx+1)
            for m in ms:
                ind_this_m = m+mmx
                ind_this_minus_m = 2*mmx-ind_this_m
                df[ind_this_m,:] = m*f[ind_this_minus_m,:]

            return f,df

    def get_basis_spline_weights(self,abslats):
        """
        Use spline interpolation on the AMGeO latitude grid
        for each given lat, so that we can get a linear combination
        of the basis function for each m at adjacent latitudes
        that best represents the weights for each m
        value basis subset for each given lat
        """

        self._check_latitudes_are_positive(abslats)
        self._check_arrays_are_flat(abslats)

        theta = np.radians(90.-abslats)

        #x represents a 'latitude index'
        x = theta/self.qmeta['dth']
        #ith is the closest index into the AMGeO basis latitude grid to each latitude
        #in abslats
        ith = x.copy()
        #I changed the upper limit to -3 to debug an index error
        #ith = np.around(np.clip(ith,1,self.qmeta['ithmx']-2)).astype(int)
        ith = np.around(np.clip(ith,1,self.qmeta['ithmx']-3)).astype(int)

        #x is now distance in index units between each value in abslats and it's closest
        #grid latitude (ith)
        x = x - ith

        #Now perform a type of spline interpolation in latitude direction
        xm1 = x*(-2. + x*(3. - x))/6. #x minus 1
        x0  = 1.+ x*(-.5 + x*(-1. + .5*x)) #x
        xp1 = x*( 1. + x*(.5 - .5*x)) #x plus 1
        xp2 = x*(-1. + x*x)/6# x plus 2
        return ith,xm1,x0,xp1,xp2

    def basis_functions(self,abslats,lons,derivatives=False):
        """
        Get the amgeo basis function values at locations abslats,lons
        (and optionally, the basis function (partial?) derivatives)

        Inputs:
            abslats - np.ndarray, nloc
                Array of absolute Apex latitudes
            lons - np.ndarray, nloc
                Array of Apex longitudes
            derivatives - bool, optional
                Return also the partials of the potential WRT
                latitude (theta) and longitude (phi)

        Returns:

            if not derivatives:

                bfuns - np.ndarray, shape=(nloc,nbasis=244)
                    Value of each of the 244 basis functions
                    at each of the nloc locations

            if derivatives:

                bfuns, dbfuns_dth, dbfuns_dph - np.ndarray, shape=(nloc,nbasis=244)
                    Value of basis functions and their derivatives
                    for each of the 244 basis functions
                    at each of the nloc locations


        """
        self._check_latitudes_are_positive(abslats)
        self._check_arrays_are_flat(abslats,lons)

        if abslats.shape != lons.shape:
            raise ValueError('Latitude array shape (%s) and longitude array shape (%s) must be equal' % (str(abslats.shape),str(lons.shape)))

        mmx = self.qmeta['mmx']
        nlocs = len(lons)

        #Create arrays for the basis functions and their derivatives (if we want them)
        bfuns = np.ndarray(shape=(nlocs,self.iem[2*mmx]+1),dtype=np.float64)
        if derivatives:
            dbfuns_dth = np.ndarray(shape=(nlocs,self.iem[2*mmx]+1),dtype=np.float64)
            dbfuns_dph = np.ndarray(shape=(nlocs,self.iem[2*mmx]+1),dtype=np.float64)

        #Always get the derivative, because it doesn't cost much extra and
        #makes the rest of the code more readable
        f_m,df_m = self.compute_f(lons,derivative=True)

        ith,xm1,x0,xp1,xp2 = self.get_basis_spline_weights(abslats)

        all_m = range(-mmx,mmx+1)
        for i_m,m in enumerate(all_m):
            # f_m for all longitudes for this m
            this_f_m = f_m[i_m,:]
            # derivative of f_m wrt longitude for this m (only used if derivatives is True)
            this_df_m = df_m[i_m,:]

            #Find the basis function numbers which correspond to all basis functions
            #for this value of m
            i_basisfcn_m = range(self.ibm[i_m],self.iem[i_m]+1)

            row_n_start = self.ns[abs(m)] # Row at which the n values start for this m
            # nmx(m) = mxnmx-|m|
            for i_n,i_basisfcn in enumerate(i_basisfcn_m):
                # Q We are skipping one row for each value of m...why? Because only use half of the basis functions in
                # this sum
                this_n_row = row_n_start+2*i_n # This would be symmetric, i.e. m < 0, so f_m~cos(m*phi)

                #Part of basis functions that varies with theta (latitude)
                this_bfuns_th = (xm1*self.q[this_n_row,ith-1] +
                               x0*self.q[this_n_row,ith] +
                               xp1*self.q[this_n_row,ith+1] +
                               xp2*self.q[this_n_row,ith+2])

                #Part of basis functions that varies with phi (longitude) is f_m
                bfuns[:,i_basisfcn] = this_bfuns_th*this_f_m

                if derivatives:
                    #Derivative of part of potential that varies with theta (latitude) WRT theta
                    this_dbfuns_dth = (xm1*self.dq[this_n_row,ith-1] +
                                       x0*self.dq[this_n_row,ith] +
                                       xp1*self.dq[this_n_row,ith+1] +
                                       xp2*self.dq[this_n_row,ith+2])

                    #Partial derivative WRT phi is just theta part times phi derivative of f_m
                    dbfuns_dph[:,i_basisfcn] = this_bfuns_th*this_df_m
                    #Partial derivative WRT theta is theta derivative of theta part times f_m
                    dbfuns_dth[:,i_basisfcn] = this_dbfuns_dth*this_f_m

        #Return based on derivatives settings
        if not derivatives:
            return bfuns
        else:
            return bfuns,dbfuns_dph,dbfuns_dth

# This is purely a container class, it is not stateful, meaning
# it's class properties will never change
# which means this single instance
# can be imported and used by all other modules
basis_functions_set = BasisFunctionsSet()
