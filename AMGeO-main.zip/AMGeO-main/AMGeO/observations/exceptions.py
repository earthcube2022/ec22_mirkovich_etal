#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
class DataWindowBoundaryError(Exception):
    """Raised by get_time_mask methods when
    the start and end times for data requested
    are outside the range of available times"""
    pass

class NoDataAvailableError(Exception):
    """Raised by get_obs_in_time methods when
    no data are left for a particular time range
    after applying all hemisphere,
    latitude, missing data, and station masks"""
    pass
