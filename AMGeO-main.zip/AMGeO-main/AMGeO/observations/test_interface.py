#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import shutil,tempfile,datetime
from collections import OrderedDict
import numpy as np
from numpy import testing as nptests
from AMGeO.datamodel.record import RecordMetadata
from AMGeO.observations.interface import ObservationsBase
from AMGeO.observations.interface import Observations

from geospacepy import special_datetime

class WaveyObservations(object):
    """Mock up of a class which implements the Observations Interface.
    Data are sinusoids"""

    def __init__(self,dt,hemisphere):

        npts = 100
        self.dt = dt
        self._hemicheck(hemisphere)
        self.hemisphere = hemisphere

        self['dts'] = np.array([dt+datetime.timedelta(minutes=i) for i in range(npts)])
        self['jds'] = special_datetime.datetimearr2jd(self['dts']).flatten()

        self['lats'] = np.linspace(40.,90.,npts)*(1. if hemisphere is 'N' else -1.)
        self['lons'] = np.linspace(0.,360.,npts)
        m = np.arange(npts)
        x = self._random_radians(npts)
        xerr = self._random_radians(npts)/10.
        self['data_eastward'] = np.cos(x)
        self['data_equatorward'] = np.sin(x)
        self['std_eastward'] = np.cos(xerr)
        self['std_equatorward'] = np.sin(xerr)

        self.observer_id = np.array([1 if this_x>np.pi else 2 for this_x in x])

        self._metadata = RecordMetadata('wav','Wavey Observations','hogsheads')

    @staticmethod
    def _random_radians(n_points):
        return np.random.rand(n_points)*2.*np.pi

    @staticmethod
    def _hemicheck(hemisphere):
        if hemisphere not in ['N','S']:
            raise ValueError('N or S please')

    def __setitem__(self,item,value):
        if not hasattr(self,'_observation_data'):
            self._observation_data = OrderedDict()
        self._observation_data[item]=value

    def __getitem__(self,item):
        return self._observation_data[item]

    def __contains__(self,item):
        return item in self._observation_data

    def __iter__(self):
        for item in self._observation_data:
            yield item

    def items(self):
        for key,value in self._observation_data.items():
            yield key,value


    def _get_time_mask(self,startdt,enddt):
        startjd = special_datetime.datetime2jd(startdt)
        endjd = special_datetime.datetime2jd(enddt)
        return np.logical_and(self['jds']>startjd,self['jds']<endjd)

    def _get_hemisphere_mask(self,hemisphere):
        if hemisphere==self.hemisphere:
            return np.ones(self['lats'].shape,dtype=bool)
        else:
            return np.zeros(self['lats'].shape,dtype=bool)

    def _get_allowed_observers_mask(self,allowed_observers):
        in_allowed = np.zeros(self.observer_id.shape,dtype='bool')
        for observer in allowed_observers:
            in_allowed = np.logical_or(in_allowed,self.observer_id==observer)
        return in_allowed

    def _get_data_window_mask(self,startdt,enddt,hemisphere,allowed_observers):
        in_window = np.ones(self['dts'].shape,dtype=bool)
        in_window = np.logical_and(in_window,self._get_time_mask(startdt,enddt))
        in_window = np.logical_and(in_window,self._get_hemisphere_mask(hemisphere))
        in_window = np.logical_and(in_window,self._get_allowed_observers_mask(allowed_observers))
        return in_window

    def get_data_window(self,startdt,enddt,hemisphere,allowed_observers):
        mask = self._get_data_window_mask(startdt,enddt,hemisphere,allowed_observers)
        datadict = OrderedDict()
        for varname,vararr in self.items():
            datadict[varname]=vararr[mask]

        metadata = self._metadata.copy()
        metadata['window_startdt']=startdt
        metadata['window_enddt']=enddt
        metadata['window_allowed_observers']=allowed_observers
        return datadict,metadata

    def get_ingest_data(self,startdt,enddt,hemisphere,allowed_observers):
        datadict,metadata = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)
        lats=datadict['lats']
        lons=datadict['lons']

        y_ph,y_th = datadict['data_eastward'],datadict['data_equatorward']
        y_std_ph,y_std_th = datadict['std_eastward'],datadict['std_equatorward']

        y = np.dstack((y_ph,y_th))
        y_var = np.dstack((y_std_ph**2,y_std_th**2))

        n_pts = len(y_ph.flatten())

        H = np.dstack((np.eye(n_pts),-1*np.eye(n_pts)))

        ymeta = metadata

        return lats,lons,y,y_var,H,ymeta

class ObservationsBaseSubclass(ObservationsBase):
    def __init__(self,observations,allowed_observers,component_name=None):
        ObservationsBase.__init__(self,
                                  observations,
                                  allowed_observers,
                                  component_name=component_name)

def _date():
    year = 2000
    month = 1
    day = 1
    return year,month,day

@pytest.fixture
def fake_observations():
    year,month,day = _date()
    hemisphere = 'N'
    wavey_observations = WaveyObservations(datetime.datetime(year,month,day),'N')
    return wavey_observations

def test_wrapper_get_ingest_data_same_as_obs_get_ingest_data(fake_observations):
    year,month,day = _date()
    dt = datetime.datetime(year,month,day,1,2,30)
    hemisphere = 'N'

    allowed_observers = [1,2]

    wrapped_fake_observations = ObservationsBaseSubclass(fake_observations,
                                                         allowed_observers,
                                                         component_name=None)

    wrapped_outs = wrapped_fake_observations.get_ingest_data(dt,hemisphere)
    wrapped_y = wrapped_outs[2]

    startdt,enddt = wrapped_fake_observations._dt_to_startdt_enddt(dt)
    naked_outs = fake_observations.get_ingest_data(startdt,enddt,
                                                    hemisphere,
                                                    allowed_observers)
    naked_y = naked_outs[2]

    assert np.array_equal(wrapped_y,naked_y)

def test_Observations_wrapper_component_indexing_works(fake_observations):
    year,month,day = _date()
    dt = datetime.datetime(year,month,day,1,2,30)
    hemisphere = 'N'

    wrapped_fake_observations = Observations(fake_observations,
                                                component_name='eastward')

    wrapped_outs = wrapped_fake_observations.get_ingest_data(dt,hemisphere)
    wrapped_y = wrapped_outs[2]
    wrapped_H = wrapped_outs[4]

    allowed_observers = 'all'
    startdt,enddt = wrapped_fake_observations._dt_to_startdt_enddt(dt)
    naked_outs = fake_observations.get_ingest_data(startdt,enddt,
                                                    hemisphere,
                                                    allowed_observers)

    #eastward direction is element 0 of 3rd dimension by AMGeO global convention
    naked_y = naked_outs[2][:,:,0]
    naked_H = naked_outs[4][:,:,0]

    assert np.array_equal(wrapped_H,naked_H)
    assert np.array_equal(wrapped_y,naked_y)

def test_metadata_is_changed_for_component(fake_observations):

    year,month,day = _date()
    dt = datetime.datetime(year,month,day,1,2,30)
    hemisphere = 'N'
    component_name = 'eastward'

    wrapped_fake_obs = Observations(fake_observations,component_name=None)

    wrapped_fake_obs_component = Observations(fake_observations,component_name=component_name)

    outs = wrapped_fake_obs.get_ingest_data(dt,hemisphere)
    component_outs = wrapped_fake_obs_component.get_ingest_data(dt,hemisphere)

    component_meta = component_outs[-1]
    meta = outs[-1]

    assert component_name in component_meta['longname']

